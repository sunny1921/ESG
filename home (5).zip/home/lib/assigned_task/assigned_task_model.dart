import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'assigned_task_widget.dart' show AssignedTaskWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:provider/provider.dart';

class AssignedTaskModel extends FlutterFlowModel<AssignedTaskWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for ChoiceChips widget.
  String? choiceChipsValue;
  FormFieldController<List<String>>? choiceChipsValueController;
  // State field(s) for mobileView widget.

  PagingController<DocumentSnapshot?, TasksRecord>? mobileViewPagingController;
  Query? mobileViewPagingQuery;
  List<StreamSubscription?> mobileViewStreamSubscriptions = [];

  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {
    unfocusNode.dispose();
    mobileViewStreamSubscriptions.forEach((s) => s?.cancel());
    mobileViewPagingController?.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.

  PagingController<DocumentSnapshot?, TasksRecord> setMobileViewController(
    Query query, {
    DocumentReference<Object?>? parent,
  }) {
    mobileViewPagingController ??= _createMobileViewController(query, parent);
    if (mobileViewPagingQuery != query) {
      mobileViewPagingQuery = query;
      mobileViewPagingController?.refresh();
    }
    return mobileViewPagingController!;
  }

  PagingController<DocumentSnapshot?, TasksRecord> _createMobileViewController(
    Query query,
    DocumentReference<Object?>? parent,
  ) {
    final controller =
        PagingController<DocumentSnapshot?, TasksRecord>(firstPageKey: null);
    return controller
      ..addPageRequestListener(
        (nextPageMarker) => queryTasksRecordPage(
          queryBuilder: (_) => mobileViewPagingQuery ??= query,
          nextPageMarker: nextPageMarker,
          streamSubscriptions: mobileViewStreamSubscriptions,
          controller: controller,
          pageSize: 25,
          isStream: true,
        ),
      );
  }
}
