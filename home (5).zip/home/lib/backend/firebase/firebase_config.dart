import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyB-CfNqJPNOar67KynileJERJ3y-AxJrCU",
            authDomain: "app1-sai-questions.firebaseapp.com",
            projectId: "app1-sai-questions",
            storageBucket: "app1-sai-questions.appspot.com",
            messagingSenderId: "231710865180",
            appId: "1:231710865180:web:0c288dda87989364d56cd9",
            measurementId: "G-X987GCM7KE"));
  } else {
    await Firebase.initializeApp();
  }
}
