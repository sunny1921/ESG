import 'dart:async';
import 'dart:convert';

import 'serialization_util.dart';
import '../backend.dart';
import '../../flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';

import '../../index.dart';
import '../../main.dart';

final _handledMessageIds = <String?>{};

class PushNotificationsHandler extends StatefulWidget {
  const PushNotificationsHandler({Key? key, required this.child})
      : super(key: key);

  final Widget child;

  @override
  _PushNotificationsHandlerState createState() =>
      _PushNotificationsHandlerState();
}

class _PushNotificationsHandlerState extends State<PushNotificationsHandler> {
  bool _loading = false;

  Future handleOpenedPushNotification() async {
    if (isWeb) {
      return;
    }

    final notification = await FirebaseMessaging.instance.getInitialMessage();
    if (notification != null) {
      await _handlePushNotification(notification);
    }
    FirebaseMessaging.onMessageOpenedApp.listen(_handlePushNotification);
  }

  Future _handlePushNotification(RemoteMessage message) async {
    if (_handledMessageIds.contains(message.messageId)) {
      return;
    }
    _handledMessageIds.add(message.messageId);

    if (mounted) {
      setState(() => _loading = true);
    }
    try {
      final initialPageName = message.data['initialPageName'] as String;
      final initialParameterData = getInitialParameterData(message.data);
      final parametersBuilder = parametersBuilderMap[initialPageName];
      if (parametersBuilder != null) {
        final parameterData = await parametersBuilder(initialParameterData);
        context.pushNamed(
          initialPageName,
          pathParameters: parameterData.pathParameters,
          extra: parameterData.extra,
        );
      }
    } catch (e) {
      print('Error: $e');
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  @override
  void initState() {
    super.initState();
    handleOpenedPushNotification();
  }

  @override
  Widget build(BuildContext context) => _loading
      ? Center(
          child: SizedBox(
            width: 35.0,
            height: 35.0,
            child: SpinKitSquareCircle(
              color: FlutterFlowTheme.of(context).lineColor,
              size: 35.0,
            ),
          ),
        )
      : widget.child;
}

class ParameterData {
  const ParameterData(
      {this.requiredParams = const {}, this.allParams = const {}});
  final Map<String, String?> requiredParams;
  final Map<String, dynamic> allParams;

  Map<String, String> get pathParameters => Map.fromEntries(
        requiredParams.entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
  Map<String, dynamic> get extra => Map.fromEntries(
        allParams.entries.where((e) => e.value != null),
      );

  static Future<ParameterData> Function(Map<String, dynamic>) none() =>
      (data) async => ParameterData();
}

final parametersBuilderMap =
    <String, Future<ParameterData> Function(Map<String, dynamic>)>{
  'HomePage': ParameterData.none(),
  'social': ParameterData.none(),
  'Action': ParameterData.none(),
  'Create': ParameterData.none(),
  'profile1': ParameterData.none(),
  'Volunteer1': (data) async => ParameterData(
        allParams: {
          'eventRef': getParameter<DocumentReference>(data, 'eventRef'),
        },
      ),
  'REPORT': ParameterData.none(),
  'NOTIF': ParameterData.none(),
  'DASHBOARD_TASK': ParameterData.none(),
  'ASSIGNED_TASK': ParameterData.none(),
  'MEMBERS': ParameterData.none(),
  'LEARNING': ParameterData.none(),
  'TASK_SUBMIT': (data) async => ParameterData(
        allParams: {
          'taskDeadline': getParameter<DateTime>(data, 'taskDeadline'),
          'taskid': getParameter<DocumentReference>(data, 'taskid'),
        },
      ),
  'Create_tas': ParameterData.none(),
  'evaluate': ParameterData.none(),
  'Action_DESCRIPTION': ParameterData.none(),
  'volunteer': (data) async => ParameterData(
        allParams: {
          'eventTitle': getParameter<String>(data, 'eventTitle'),
          'eventDetails': getParameter<String>(data, 'eventDetails'),
          'eventPhoto': getParameter<String>(data, 'eventPhoto'),
          'eventStart': getParameter<DateTime>(data, 'eventStart'),
          'eventEnd': getParameter<DateTime>(data, 'eventEnd'),
          'location': getParameter<String>(data, 'location'),
          'eventRef': getParameter<DocumentReference>(data, 'eventRef'),
        },
      ),
  'leaderboard': ParameterData.none(),
  'viewtaskimageforteacher': (data) async => ParameterData(
        allParams: {},
      ),
  'statistics': ParameterData.none(),
  'community': ParameterData.none(),
  'login': ParameterData.none(),
  'create_acc': ParameterData.none(),
  'campus1': ParameterData.none(),
  'TaskEvaluationForStudent': (data) async => ParameterData(
        allParams: {
          'taskDeadline': getParameter<DateTime>(data, 'taskDeadline'),
          'taskid': getParameter<DocumentReference>(data, 'taskid'),
        },
      ),
  'ViewReports': ParameterData.none(),
  'viewReportImageForRole': (data) async => ParameterData(
        allParams: {
          'photoList': getParameter<String>(data, 'photoList'),
        },
      ),
  'surveyIntro': ParameterData.none(),
  'Survey_Page': (data) async => ParameterData(
        allParams: {
          'question': getParameter<DocumentReference>(data, 'question'),
        },
      ),
  'survey_result': ParameterData.none(),
  'democalc': ParameterData.none(),
};

Map<String, dynamic> getInitialParameterData(Map<String, dynamic> data) {
  try {
    final parameterDataStr = data['parameterData'];
    if (parameterDataStr == null ||
        parameterDataStr is! String ||
        parameterDataStr.isEmpty) {
      return {};
    }
    return jsonDecode(parameterDataStr) as Map<String, dynamic>;
  } catch (e) {
    print('Error parsing parameter data: $e');
    return {};
  }
}
