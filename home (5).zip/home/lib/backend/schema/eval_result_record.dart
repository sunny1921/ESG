import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class EvalResultRecord extends FirestoreRecord {
  EvalResultRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Points" field.
  int? _points;
  int get points => _points ?? 0;
  bool hasPoints() => _points != null;

  // "feedback" field.
  String? _feedback;
  String get feedback => _feedback ?? '';
  bool hasFeedback() => _feedback != null;

  // "evalPhoto" field.
  String? _evalPhoto;
  String get evalPhoto => _evalPhoto ?? '';
  bool hasEvalPhoto() => _evalPhoto != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _points = castToType<int>(snapshotData['Points']);
    _feedback = snapshotData['feedback'] as String?;
    _evalPhoto = snapshotData['evalPhoto'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('evalResult')
          : FirebaseFirestore.instance.collectionGroup('evalResult');

  static DocumentReference createDoc(DocumentReference parent) =>
      parent.collection('evalResult').doc();

  static Stream<EvalResultRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => EvalResultRecord.fromSnapshot(s));

  static Future<EvalResultRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => EvalResultRecord.fromSnapshot(s));

  static EvalResultRecord fromSnapshot(DocumentSnapshot snapshot) =>
      EvalResultRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static EvalResultRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      EvalResultRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'EvalResultRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is EvalResultRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createEvalResultRecordData({
  int? points,
  String? feedback,
  String? evalPhoto,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Points': points,
      'feedback': feedback,
      'evalPhoto': evalPhoto,
    }.withoutNulls,
  );

  return firestoreData;
}

class EvalResultRecordDocumentEquality implements Equality<EvalResultRecord> {
  const EvalResultRecordDocumentEquality();

  @override
  bool equals(EvalResultRecord? e1, EvalResultRecord? e2) {
    return e1?.points == e2?.points &&
        e1?.feedback == e2?.feedback &&
        e1?.evalPhoto == e2?.evalPhoto;
  }

  @override
  int hash(EvalResultRecord? e) =>
      const ListEquality().hash([e?.points, e?.feedback, e?.evalPhoto]);

  @override
  bool isValidKey(Object? o) => o is EvalResultRecord;
}
