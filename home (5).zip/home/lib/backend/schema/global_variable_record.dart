import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class GlobalVariableRecord extends FirestoreRecord {
  GlobalVariableRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "totalCarbonFootPrint" field.
  double? _totalCarbonFootPrint;
  double get totalCarbonFootPrint => _totalCarbonFootPrint ?? 0.0;
  bool hasTotalCarbonFootPrint() => _totalCarbonFootPrint != null;

  // "totalWaterUsage" field.
  double? _totalWaterUsage;
  double get totalWaterUsage => _totalWaterUsage ?? 0.0;
  bool hasTotalWaterUsage() => _totalWaterUsage != null;

  // "totalEnergyConsumption" field.
  double? _totalEnergyConsumption;
  double get totalEnergyConsumption => _totalEnergyConsumption ?? 0.0;
  bool hasTotalEnergyConsumption() => _totalEnergyConsumption != null;

  // "totalUsers" field.
  int? _totalUsers;
  int get totalUsers => _totalUsers ?? 0;
  bool hasTotalUsers() => _totalUsers != null;

  void _initializeFields() {
    _totalCarbonFootPrint =
        castToType<double>(snapshotData['totalCarbonFootPrint']);
    _totalWaterUsage = castToType<double>(snapshotData['totalWaterUsage']);
    _totalEnergyConsumption =
        castToType<double>(snapshotData['totalEnergyConsumption']);
    _totalUsers = castToType<int>(snapshotData['totalUsers']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('globalVariable');

  static Stream<GlobalVariableRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => GlobalVariableRecord.fromSnapshot(s));

  static Future<GlobalVariableRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => GlobalVariableRecord.fromSnapshot(s));

  static GlobalVariableRecord fromSnapshot(DocumentSnapshot snapshot) =>
      GlobalVariableRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static GlobalVariableRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      GlobalVariableRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'GlobalVariableRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is GlobalVariableRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createGlobalVariableRecordData({
  double? totalCarbonFootPrint,
  double? totalWaterUsage,
  double? totalEnergyConsumption,
  int? totalUsers,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'totalCarbonFootPrint': totalCarbonFootPrint,
      'totalWaterUsage': totalWaterUsage,
      'totalEnergyConsumption': totalEnergyConsumption,
      'totalUsers': totalUsers,
    }.withoutNulls,
  );

  return firestoreData;
}

class GlobalVariableRecordDocumentEquality
    implements Equality<GlobalVariableRecord> {
  const GlobalVariableRecordDocumentEquality();

  @override
  bool equals(GlobalVariableRecord? e1, GlobalVariableRecord? e2) {
    return e1?.totalCarbonFootPrint == e2?.totalCarbonFootPrint &&
        e1?.totalWaterUsage == e2?.totalWaterUsage &&
        e1?.totalEnergyConsumption == e2?.totalEnergyConsumption &&
        e1?.totalUsers == e2?.totalUsers;
  }

  @override
  int hash(GlobalVariableRecord? e) => const ListEquality().hash([
        e?.totalCarbonFootPrint,
        e?.totalWaterUsage,
        e?.totalEnergyConsumption,
        e?.totalUsers
      ]);

  @override
  bool isValidKey(Object? o) => o is GlobalVariableRecord;
}
