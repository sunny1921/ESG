import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ProgressLogRecord extends FirestoreRecord {
  ProgressLogRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "progressNote" field.
  String? _progressNote;
  String get progressNote => _progressNote ?? '';
  bool hasProgressNote() => _progressNote != null;

  // "progressImage" field.
  List<String>? _progressImage;
  List<String> get progressImage => _progressImage ?? const [];
  bool hasProgressImage() => _progressImage != null;

  // "progressUser" field.
  DocumentReference? _progressUser;
  DocumentReference? get progressUser => _progressUser;
  bool hasProgressUser() => _progressUser != null;

  // "progressDate" field.
  DateTime? _progressDate;
  DateTime? get progressDate => _progressDate;
  bool hasProgressDate() => _progressDate != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _progressNote = snapshotData['progressNote'] as String?;
    _progressImage = getDataList(snapshotData['progressImage']);
    _progressUser = snapshotData['progressUser'] as DocumentReference?;
    _progressDate = snapshotData['progressDate'] as DateTime?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('progressLog')
          : FirebaseFirestore.instance.collectionGroup('progressLog');

  static DocumentReference createDoc(DocumentReference parent) =>
      parent.collection('progressLog').doc();

  static Stream<ProgressLogRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ProgressLogRecord.fromSnapshot(s));

  static Future<ProgressLogRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ProgressLogRecord.fromSnapshot(s));

  static ProgressLogRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ProgressLogRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ProgressLogRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ProgressLogRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ProgressLogRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ProgressLogRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createProgressLogRecordData({
  String? progressNote,
  DocumentReference? progressUser,
  DateTime? progressDate,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'progressNote': progressNote,
      'progressUser': progressUser,
      'progressDate': progressDate,
    }.withoutNulls,
  );

  return firestoreData;
}

class ProgressLogRecordDocumentEquality implements Equality<ProgressLogRecord> {
  const ProgressLogRecordDocumentEquality();

  @override
  bool equals(ProgressLogRecord? e1, ProgressLogRecord? e2) {
    const listEquality = ListEquality();
    return e1?.progressNote == e2?.progressNote &&
        listEquality.equals(e1?.progressImage, e2?.progressImage) &&
        e1?.progressUser == e2?.progressUser &&
        e1?.progressDate == e2?.progressDate;
  }

  @override
  int hash(ProgressLogRecord? e) => const ListEquality().hash(
      [e?.progressNote, e?.progressImage, e?.progressUser, e?.progressDate]);

  @override
  bool isValidKey(Object? o) => o is ProgressLogRecord;
}
