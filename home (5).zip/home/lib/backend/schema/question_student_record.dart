import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class QuestionStudentRecord extends FirestoreRecord {
  QuestionStudentRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Question" field.
  String? _question;
  String get question => _question ?? '';
  bool hasQuestion() => _question != null;

  // "Option1" field.
  String? _option1;
  String get option1 => _option1 ?? '';
  bool hasOption1() => _option1 != null;

  // "Option2" field.
  String? _option2;
  String get option2 => _option2 ?? '';
  bool hasOption2() => _option2 != null;

  // "Option3" field.
  String? _option3;
  String get option3 => _option3 ?? '';
  bool hasOption3() => _option3 != null;

  // "Option4" field.
  String? _option4;
  String get option4 => _option4 ?? '';
  bool hasOption4() => _option4 != null;

  // "Option5" field.
  String? _option5;
  String get option5 => _option5 ?? '';
  bool hasOption5() => _option5 != null;

  // "UID" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  void _initializeFields() {
    _question = snapshotData['Question'] as String?;
    _option1 = snapshotData['Option1'] as String?;
    _option2 = snapshotData['Option2'] as String?;
    _option3 = snapshotData['Option3'] as String?;
    _option4 = snapshotData['Option4'] as String?;
    _option5 = snapshotData['Option5'] as String?;
    _uid = snapshotData['UID'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('question_student');

  static Stream<QuestionStudentRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => QuestionStudentRecord.fromSnapshot(s));

  static Future<QuestionStudentRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => QuestionStudentRecord.fromSnapshot(s));

  static QuestionStudentRecord fromSnapshot(DocumentSnapshot snapshot) =>
      QuestionStudentRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static QuestionStudentRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      QuestionStudentRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'QuestionStudentRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is QuestionStudentRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createQuestionStudentRecordData({
  String? question,
  String? option1,
  String? option2,
  String? option3,
  String? option4,
  String? option5,
  String? uid,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Question': question,
      'Option1': option1,
      'Option2': option2,
      'Option3': option3,
      'Option4': option4,
      'Option5': option5,
      'UID': uid,
    }.withoutNulls,
  );

  return firestoreData;
}

class QuestionStudentRecordDocumentEquality
    implements Equality<QuestionStudentRecord> {
  const QuestionStudentRecordDocumentEquality();

  @override
  bool equals(QuestionStudentRecord? e1, QuestionStudentRecord? e2) {
    return e1?.question == e2?.question &&
        e1?.option1 == e2?.option1 &&
        e1?.option2 == e2?.option2 &&
        e1?.option3 == e2?.option3 &&
        e1?.option4 == e2?.option4 &&
        e1?.option5 == e2?.option5 &&
        e1?.uid == e2?.uid;
  }

  @override
  int hash(QuestionStudentRecord? e) => const ListEquality().hash([
        e?.question,
        e?.option1,
        e?.option2,
        e?.option3,
        e?.option4,
        e?.option5,
        e?.uid
      ]);

  @override
  bool isValidKey(Object? o) => o is QuestionStudentRecord;
}
