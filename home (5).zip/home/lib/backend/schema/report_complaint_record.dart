import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ReportComplaintRecord extends FirestoreRecord {
  ReportComplaintRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "photo" field.
  String? _photo;
  String get photo => _photo ?? '';
  bool hasPhoto() => _photo != null;

  // "department" field.
  List<String>? _department;
  List<String> get department => _department ?? const [];
  bool hasDepartment() => _department != null;

  // "reported_by" field.
  DocumentReference? _reportedBy;
  DocumentReference? get reportedBy => _reportedBy;
  bool hasReportedBy() => _reportedBy != null;

  void _initializeFields() {
    _title = snapshotData['title'] as String?;
    _description = snapshotData['description'] as String?;
    _photo = snapshotData['photo'] as String?;
    _department = getDataList(snapshotData['department']);
    _reportedBy = snapshotData['reported_by'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('report_complaint');

  static Stream<ReportComplaintRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ReportComplaintRecord.fromSnapshot(s));

  static Future<ReportComplaintRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ReportComplaintRecord.fromSnapshot(s));

  static ReportComplaintRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ReportComplaintRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ReportComplaintRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ReportComplaintRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ReportComplaintRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ReportComplaintRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createReportComplaintRecordData({
  String? title,
  String? description,
  String? photo,
  DocumentReference? reportedBy,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'title': title,
      'description': description,
      'photo': photo,
      'reported_by': reportedBy,
    }.withoutNulls,
  );

  return firestoreData;
}

class ReportComplaintRecordDocumentEquality
    implements Equality<ReportComplaintRecord> {
  const ReportComplaintRecordDocumentEquality();

  @override
  bool equals(ReportComplaintRecord? e1, ReportComplaintRecord? e2) {
    const listEquality = ListEquality();
    return e1?.title == e2?.title &&
        e1?.description == e2?.description &&
        e1?.photo == e2?.photo &&
        listEquality.equals(e1?.department, e2?.department) &&
        e1?.reportedBy == e2?.reportedBy;
  }

  @override
  int hash(ReportComplaintRecord? e) => const ListEquality()
      .hash([e?.title, e?.description, e?.photo, e?.department, e?.reportedBy]);

  @override
  bool isValidKey(Object? o) => o is ReportComplaintRecord;
}
