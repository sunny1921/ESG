// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class EvaluationResultStruct extends FFFirebaseStruct {
  EvaluationResultStruct({
    int? points,
    String? feedback,
    String? evalPhoto,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _points = points,
        _feedback = feedback,
        _evalPhoto = evalPhoto,
        super(firestoreUtilData);

  // "Points" field.
  int? _points;
  int get points => _points ?? 0;
  set points(int? val) => _points = val;
  void incrementPoints(int amount) => _points = points + amount;
  bool hasPoints() => _points != null;

  // "feedback" field.
  String? _feedback;
  String get feedback => _feedback ?? '';
  set feedback(String? val) => _feedback = val;
  bool hasFeedback() => _feedback != null;

  // "evalPhoto" field.
  String? _evalPhoto;
  String get evalPhoto => _evalPhoto ?? '';
  set evalPhoto(String? val) => _evalPhoto = val;
  bool hasEvalPhoto() => _evalPhoto != null;

  static EvaluationResultStruct fromMap(Map<String, dynamic> data) =>
      EvaluationResultStruct(
        points: castToType<int>(data['Points']),
        feedback: data['feedback'] as String?,
        evalPhoto: data['evalPhoto'] as String?,
      );

  static EvaluationResultStruct? maybeFromMap(dynamic data) => data is Map
      ? EvaluationResultStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'Points': _points,
        'feedback': _feedback,
        'evalPhoto': _evalPhoto,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'Points': serializeParam(
          _points,
          ParamType.int,
        ),
        'feedback': serializeParam(
          _feedback,
          ParamType.String,
        ),
        'evalPhoto': serializeParam(
          _evalPhoto,
          ParamType.String,
        ),
      }.withoutNulls;

  static EvaluationResultStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      EvaluationResultStruct(
        points: deserializeParam(
          data['Points'],
          ParamType.int,
          false,
        ),
        feedback: deserializeParam(
          data['feedback'],
          ParamType.String,
          false,
        ),
        evalPhoto: deserializeParam(
          data['evalPhoto'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'EvaluationResultStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is EvaluationResultStruct &&
        points == other.points &&
        feedback == other.feedback &&
        evalPhoto == other.evalPhoto;
  }

  @override
  int get hashCode => const ListEquality().hash([points, feedback, evalPhoto]);
}

EvaluationResultStruct createEvaluationResultStruct({
  int? points,
  String? feedback,
  String? evalPhoto,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    EvaluationResultStruct(
      points: points,
      feedback: feedback,
      evalPhoto: evalPhoto,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

EvaluationResultStruct? updateEvaluationResultStruct(
  EvaluationResultStruct? evaluationResult, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    evaluationResult
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addEvaluationResultStructData(
  Map<String, dynamic> firestoreData,
  EvaluationResultStruct? evaluationResult,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (evaluationResult == null) {
    return;
  }
  if (evaluationResult.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && evaluationResult.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final evaluationResultData =
      getEvaluationResultFirestoreData(evaluationResult, forFieldValue);
  final nestedData =
      evaluationResultData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = evaluationResult.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getEvaluationResultFirestoreData(
  EvaluationResultStruct? evaluationResult, [
  bool forFieldValue = false,
]) {
  if (evaluationResult == null) {
    return {};
  }
  final firestoreData = mapToFirestore(evaluationResult.toMap());

  // Add any Firestore field values
  evaluationResult.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getEvaluationResultListFirestoreData(
  List<EvaluationResultStruct>? evaluationResults,
) =>
    evaluationResults
        ?.map((e) => getEvaluationResultFirestoreData(e, true))
        .toList() ??
    [];
