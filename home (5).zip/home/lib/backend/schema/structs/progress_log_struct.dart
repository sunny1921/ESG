// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ProgressLogStruct extends FFFirebaseStruct {
  ProgressLogStruct({
    String? progressNote,
    List<String>? progressImage,
    DocumentReference? progressUser,
    DateTime? date,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _progressNote = progressNote,
        _progressImage = progressImage,
        _progressUser = progressUser,
        _date = date,
        super(firestoreUtilData);

  // "ProgressNote" field.
  String? _progressNote;
  String get progressNote => _progressNote ?? '';
  set progressNote(String? val) => _progressNote = val;
  bool hasProgressNote() => _progressNote != null;

  // "ProgressImage" field.
  List<String>? _progressImage;
  List<String> get progressImage => _progressImage ?? const [];
  set progressImage(List<String>? val) => _progressImage = val;
  void updateProgressImage(Function(List<String>) updateFn) =>
      updateFn(_progressImage ??= []);
  bool hasProgressImage() => _progressImage != null;

  // "progress_user" field.
  DocumentReference? _progressUser;
  DocumentReference? get progressUser => _progressUser;
  set progressUser(DocumentReference? val) => _progressUser = val;
  bool hasProgressUser() => _progressUser != null;

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  set date(DateTime? val) => _date = val;
  bool hasDate() => _date != null;

  static ProgressLogStruct fromMap(Map<String, dynamic> data) =>
      ProgressLogStruct(
        progressNote: data['ProgressNote'] as String?,
        progressImage: getDataList(data['ProgressImage']),
        progressUser: data['progress_user'] as DocumentReference?,
        date: data['date'] as DateTime?,
      );

  static ProgressLogStruct? maybeFromMap(dynamic data) => data is Map
      ? ProgressLogStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'ProgressNote': _progressNote,
        'ProgressImage': _progressImage,
        'progress_user': _progressUser,
        'date': _date,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'ProgressNote': serializeParam(
          _progressNote,
          ParamType.String,
        ),
        'ProgressImage': serializeParam(
          _progressImage,
          ParamType.String,
          true,
        ),
        'progress_user': serializeParam(
          _progressUser,
          ParamType.DocumentReference,
        ),
        'date': serializeParam(
          _date,
          ParamType.DateTime,
        ),
      }.withoutNulls;

  static ProgressLogStruct fromSerializableMap(Map<String, dynamic> data) =>
      ProgressLogStruct(
        progressNote: deserializeParam(
          data['ProgressNote'],
          ParamType.String,
          false,
        ),
        progressImage: deserializeParam<String>(
          data['ProgressImage'],
          ParamType.String,
          true,
        ),
        progressUser: deserializeParam(
          data['progress_user'],
          ParamType.DocumentReference,
          false,
          collectionNamePath: ['users'],
        ),
        date: deserializeParam(
          data['date'],
          ParamType.DateTime,
          false,
        ),
      );

  @override
  String toString() => 'ProgressLogStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is ProgressLogStruct &&
        progressNote == other.progressNote &&
        listEquality.equals(progressImage, other.progressImage) &&
        progressUser == other.progressUser &&
        date == other.date;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([progressNote, progressImage, progressUser, date]);
}

ProgressLogStruct createProgressLogStruct({
  String? progressNote,
  DocumentReference? progressUser,
  DateTime? date,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    ProgressLogStruct(
      progressNote: progressNote,
      progressUser: progressUser,
      date: date,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

ProgressLogStruct? updateProgressLogStruct(
  ProgressLogStruct? progressLog, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    progressLog
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addProgressLogStructData(
  Map<String, dynamic> firestoreData,
  ProgressLogStruct? progressLog,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (progressLog == null) {
    return;
  }
  if (progressLog.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && progressLog.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final progressLogData =
      getProgressLogFirestoreData(progressLog, forFieldValue);
  final nestedData =
      progressLogData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = progressLog.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getProgressLogFirestoreData(
  ProgressLogStruct? progressLog, [
  bool forFieldValue = false,
]) {
  if (progressLog == null) {
    return {};
  }
  final firestoreData = mapToFirestore(progressLog.toMap());

  // Add any Firestore field values
  progressLog.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getProgressLogListFirestoreData(
  List<ProgressLogStruct>? progressLogs,
) =>
    progressLogs?.map((e) => getProgressLogFirestoreData(e, true)).toList() ??
    [];
