// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Imports custom actions

class TripleCircularProgress extends StatelessWidget {
  final double? width;
  final double? height;
  final double progress1;
  final double progress2;
  final double progress3;
  final double numquest;

  TripleCircularProgress({
    this.width,
    this.height,
    required this.progress1,
    required this.progress2,
    required this.progress3,
    required this.numquest,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              _CircularProgress(
                progress: (progress3 / (numquest * 5)),
                radius: 160.0,
                color: Colors.orange,
              ),
              _CircularProgress(
                progress: (progress2 / (numquest * 5)),
                radius: 120.0,
                color: Colors.green,
              ),
              _CircularProgress(
                progress: (progress1 / (numquest * 5)),
                radius: 80.0,
                color: Colors.blue,
              ),
            ],
          ),
          SizedBox(height: 20.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'You:',
                style: TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue),
              ),
              Text(
                ' $progress1',
                style: const TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 255, 255, 255)),
              ),
              const SizedBox(width: 20.0),
              const Text(
                'Institute:',
                style: TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.green),
              ),
              Text(
                ' $progress2',
                style: const TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 255, 255, 255)),
              ),
              const SizedBox(width: 20.0),
              const Text(
                'State:',
                style: TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.orange),
              ),
              Text(
                ' $progress3',
                style: const TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 255, 255, 255)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _CircularProgress extends StatelessWidget {
  final double progress;
  final double radius;
  final Color color;

  _CircularProgress({
    required this.progress,
    required this.radius,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned(
      child: Container(
        padding: EdgeInsets.all(10.0),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
        ),
        child: Container(
          width: radius * 2,
          height: radius * 2,
          child: CircularProgressIndicator(
            value: progress,
            strokeWidth: 30.0,
            valueColor: AlwaysStoppedAnimation<Color>(color),
            backgroundColor: Colors.grey[300],
          ),
        ),
      ),
    );
  }
}
