import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'hi'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? hiText = '',
  }) =>
      [enText, hiText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    final language = locale.toString();
    return FFLocalizations.languages().contains(
      language.endsWith('_')
          ? language.substring(0, language.length - 1)
          : language,
    );
  }

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // HomePage
  {
    '1886zvh8': {
      'en': 'हिंदी',
      'hi': '',
    },
    '15ngtn5q': {
      'en': 'Update Data',
      'hi': '',
    },
    '6j7mutq5': {
      'en': 'LOGOUT',
      'hi': 'लॉग आउट',
    },
    'iik08jmp': {
      'en': 'REPORT',
      'hi': 'प्रतिवेदन',
    },
    'bdfnnwzn': {
      'en': 'VIEW REPORTS',
      'hi': 'रिपोर्ट देखें',
    },
    'oj4236pg': {
      'en': 'LEVELS',
      'hi': 'स्तरों',
    },
    'xydcqh7s': {
      'en': 'EVENT CALENDAR',
      'hi': 'कार्यक्रम का कैलेंडर',
    },
    'u3urytqv': {
      'en': 'EMISSIONS',
      'hi': 'उत्सर्जन',
    },
    'isnz1l9h': {
      'en': 'WEARABLES',
      'hi': 'पहनने योग्य',
    },
    '19je4nbt': {
      'en': 'CAMPUS',
      'hi': 'कैंपस',
    },
    '8lvz2ut5': {
      'en': '35\nUNITS',
      'hi': '35\nइकाइयां',
    },
    'w0igt8gt': {
      'en': 'Target: ',
      'hi': '',
    },
    'rbm1t5dm': {
      'en': '525\nLITRES',
      'hi': '525\nलीटर',
    },
    'cjymcytk': {
      'en': 'Target: ',
      'hi': '',
    },
    'ic81zoz6': {
      'en': '2\nKILOTONS',
      'hi': '2\nकिलोटन',
    },
    'tdjdzabt': {
      'en': 'Target: ',
      'hi': '',
    },
    'hx30mxa5': {
      'en': 'LEVEL 1',
      'hi': 'स्तर 1',
    },
    '8ulm5xzj': {
      'en': 'SEED',
      'hi': 'बीज',
    },
    '7thsqm2c': {
      'en': 'Leader Board',
      'hi': 'लीडर बोर्ड',
    },
    'ac2sif4q': {
      'en': 'LEADERBOARD',
      'hi': 'लीडरबोर्ड',
    },
    '9232h8pj': {
      'en': 'TASK MANAGEMENT',
      'hi': 'कार्य प्रबंधन',
    },
    'gtokmf5d': {
      'en':
          '      The most environmentally friendly product is one you did not buy.',
      'hi': 'सबसे पर्यावरण अनुकूल उत्पाद वह है जिसे आपने नहीं खरीदा।',
    },
    'v8dtgt1z': {
      'en': 'Sustainable Tips',
      'hi': 'सतत युक्तियाँ',
    },
    'k0c2744k': {
      'en': 'The most environmentally friendly product is one you did not buy.',
      'hi': 'सबसे पर्यावरण अनुकूल उत्पाद वह है जिसे आपने नहीं खरीदा।',
    },
    '3l0pmjtz': {
      'en': 'Sustainable Tips',
      'hi': 'सतत युक्तियाँ',
    },
    'xkd9nn8o': {
      'en': 'The most environmentally friendly product is one you did not buy.',
      'hi': 'सबसे पर्यावरण अनुकूल उत्पाद वह है जिसे आपने नहीं खरीदा।',
    },
    '6gby6z9e': {
      'en': 'Sustainable Tips',
      'hi': 'सतत युक्तियाँ',
    },
    'drppw44s': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // social
  {
    'qc4ybmzk': {
      'en': 'Sunny Kumar',
      'hi': 'सन्नी कुमार',
    },
    'ytz4n364': {
      'en': '@samchan',
      'hi': '@समचान',
    },
    'nqvu6i3q': {
      'en': 'What\'s on your mind?',
      'hi': 'आपके दिमाग में क्या है?',
    },
    's682oezw': {
      'en': 'Recent Posts',
      'hi': 'हाल के पोस्ट',
    },
    '5lcmf13r': {
      'en': 'View All',
      'hi': 'सभी को देखें',
    },
    'ljh8tdms': {
      'en': 'Jane Smith',
      'hi': 'जेन स्मिथ',
    },
    'qjkgq7ta': {
      'en': '@janesmith',
      'hi': '@जेन स्मिथ',
    },
    'ezjf46pc': {
      'en':
          'Join our \'Green Week Challenge\'! Reduce your carbon footprint by opting for public transport, carpooling, or biking. Share your journey and inspire others. Let\'s make a collective impact for a cleaner, greener planet! #GreenCommute #EcoChallenge',
      'hi':
          'हमारे \'ग्रीन वीक चैलेंज\' में शामिल हों! सार्वजनिक परिवहन, कारपूलिंग या बाइकिंग का विकल्प चुनकर अपने कार्बन पदचिह्न को कम करें। अपनी यात्रा साझा करें और दूसरों को प्रेरित करें। आइए एक स्वच्छ, हरित ग्रह के लिए सामूहिक प्रभाव डालें! #ग्रीनकम्यूट #इकोचैलेंज',
    },
    'nsm8ton4': {
      'en': 'Mark Johnson',
      'hi': 'मार्क जॉनसन',
    },
    '5qggv7gx': {
      'en': '@markjohnson',
      'hi': '@मार्कजॉनसन',
    },
    'z6kr5b1f': {
      'en':
          '\"Excited to announce our monthly beach clean-up this Saturday! Gather at 8 AM by the pier. Bring friends and family to help make a difference. Every hand counts in preserving our beautiful coastline. #BeachCleanUp #CommunityAction\"',
      'hi':
          '\"इस शनिवार को हमारे मासिक समुद्र तट की सफाई की घोषणा करते हुए उत्साहित हूं! घाट पर सुबह 8 बजे इकट्ठा हों। बदलाव लाने में मदद के लिए दोस्तों और परिवार को साथ लाएं। हमारी खूबसूरत तटरेखा को संरक्षित करने में हर हाथ मायने रखता है। #BeachCleanUp #CmunityAction\"',
    },
    's65tnro9': {
      'en': 'Localised Environmental Tips',
      'hi': 'स्थानीयकृत पर्यावरणीय युक्तियाँ',
    },
    '12rr1z3s': {
      'en': 'Social',
      'hi': 'सामाजिक',
    },
  },
  // Action
  {
    'fz9pninw': {
      'en': 'All Challenges',
      'hi': 'सभी चुनौतियाँ',
    },
    '2aauk7ep': {
      'en': 'Small Actions  -  Big Effects',
      'hi': 'छोटे कार्य - बड़े प्रभाव',
    },
    '25n346vn': {
      'en': 'Explore All Challenges',
      'hi': 'सभी चुनौतियों का अन्वेषण करें',
    },
    'owhw8jov': {
      'en': 'Categories',
      'hi': 'श्रेणियाँ',
    },
    'lb0i8k98': {
      'en': 'Green Challenge',
      'hi': 'हरित चुनौती',
    },
    'rho0lepi': {
      'en': '50 Pts',
      'hi': '50 अंक',
    },
    'knqz9p1t': {
      'en': 'Best Out of Waste!',
      'hi': 'बेकार की चीजों में से उत्तम चीज बनाना!',
    },
    'i0jjkh5m': {
      'en': '',
      'hi': '',
    },
    '9cqdi1ej': {
      'en': '50 Pts',
      'hi': '50 अंक',
    },
    'uze9eidx': {
      'en': 'View Now',
      'hi': 'अभी देखें',
    },
    'v6dxs91o': {
      'en': '',
      'hi': '',
    },
    '2ozn2fl5': {
      'en': '50 Pts',
      'hi': '50 अंक',
    },
    'mgrs66k4': {
      'en': 'View Now',
      'hi': 'अभी देखें',
    },
    '1xhflrkw': {
      'en': '',
      'hi': '',
    },
    'o22lzzg7': {
      'en': '50 Pts',
      'hi': '50 अंक',
    },
    '4ga5gr70': {
      'en': 'View Now',
      'hi': 'अभी देखें',
    },
    '2g7h6t04': {
      'en': 'More Challenges',
      'hi': 'अधिक चुनौतियाँ',
    },
    'reerlwi3': {
      'en': '30 Day Challenge',
      'hi': '30 दिन की चुनौती',
    },
    'v86da2vc': {
      'en':
          '\nTransform the Earth in 30 Days: Embrace bold, eco-friendly actions, ignite change, and revolutionize your environmental impact!',
      'hi':
          '30 दिनों में पृथ्वी को बदल दें: साहसिक, पर्यावरण-अनुकूल कार्यों को अपनाएं, परिवर्तन की अलख जगाएं और अपने पर्यावरणीय प्रभाव में क्रांति लाएं!',
    },
    '2t7c98y4': {
      'en': 'Circular Economy Challenge',
      'hi': 'सर्कुलर इकोनॉमी चैलेंज',
    },
    'z9iln0ew': {
      'en':
          'Transform waste into wealth! Join the Circular Economy Challenge: Innovate, Sustain, Prosper. Let\'s shape a greener future together!',
      'hi':
          'अपशिष्ट को धन में बदलें! सर्कुलर इकोनॉमी चैलेंज में शामिल हों: नवप्रवर्तन करें, कायम रहें, समृद्ध बनें। आइए मिलकर एक हरित भविष्य को आकार दें!',
    },
    'uyuupxne': {
      'en': 'Dare',
      'hi': 'हिम्मत',
    },
  },
  // Create
  {
    'aa15qvvj': {
      'en': 'Create Event',
      'hi': 'कार्यक्रम बनाएँ',
    },
    '4phdqbzl': {
      'en': 'Event Name',
      'hi': 'घटना नाम',
    },
    '0mu33ly0': {
      'en': '            Event Details',
      'hi': 'घटना की जानकारी',
    },
    'om89w1ns': {
      'en': 'Start',
      'hi': 'शुरू',
    },
    '3vvufiyb': {
      'en': 'End',
      'hi': 'अंत',
    },
    'lfbguagj': {
      'en': 'Location',
      'hi': 'जगह',
    },
    'puh9giwr': {
      'en': 'Upload Photo Related to Event',
      'hi': 'इवेंट से संबंधित फोटो अपलोड करें',
    },
    'nox97s67': {
      'en': 'Submit',
      'hi': 'जमा करना',
    },
    '36gjz9a0': {
      'en': 'Create',
      'hi': 'आयोजित करे ',
    },
  },
  // profile1
  {
    '9rari32p': {
      'en': 'My Targets',
      'hi': 'मेरे लक्ष्य',
    },
    'bctf9gy8': {
      'en': ' Notifications',
      'hi': 'सूचनाएं',
    },
    'wf1nkmax': {
      'en': 'Help Center',
      'hi': 'सहायता केंद्र',
    },
    't3bm1fnd': {
      'en': 'Settings',
      'hi': 'समायोजन',
    },
    '10hg3pog': {
      'en': 'Phone Number',
      'hi': 'फ़ोन नंबर',
    },
    'ck954s2p': {
      'en': 'Add Number',
      'hi': 'संख्या जोड़ें',
    },
    '9a3jvb48': {
      'en': 'Language',
      'hi': 'भाषा',
    },
    'wfuwenuu': {
      'en': 'English (eng)',
      'hi': 'अंग्रेज़ी',
    },
    'mbrajvzw': {
      'en': 'Currency',
      'hi': 'मुद्रा',
    },
    '525sxypu': {
      'en': 'Rupees',
      'hi': 'रुपये',
    },
    'qiroigbe': {
      'en': 'Profile Settings',
      'hi': 'पार्श्वचित्र समायोजन',
    },
    'm0zxe0bg': {
      'en': 'Edit Profile',
      'hi': 'प्रोफ़ाइल संपादित करें',
    },
    '6duabrzi': {
      'en': 'Notification Settings',
      'hi': 'अधिसूचना सेटिंग्स',
    },
    'uuf65utg': {
      'en': 'Log out of account',
      'hi': 'खाते से लॉग आउट करें',
    },
    '1rza5s4n': {
      'en': 'Log Out?',
      'hi': 'लॉग आउट?',
    },
    '4vuwoed2': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // Volunteer1
  {
    'qfeursfi': {
      'en': 'Volunteering',
      'hi': 'स्वयं सेवा',
    },
    'sp9hcoue': {
      'en': 'All Events to Volunteer',
      'hi': 'स्वयंसेवक के लिए सभी कार्यक्रम',
    },
    '6zn1jml8': {
      'en': '50 Points',
      'hi': '50 अंक',
    },
    'z9qssbd4': {
      'en': 'Volunteer',
      'hi': 'हिस्सा बने ',
    },
  },
  // REPORT
  {
    'mh7i5wph': {
      'en': 'Report',
      'hi': 'प्रतिवेदन',
    },
    'jnke4cbi': {
      'en': 'Fill out the form below to report something',
      'hi': 'किसी चीज़ की रिपोर्ट करने के लिए नीचे दिया गया फ़ॉर्म भरें',
    },
    'n8hwaetn': {
      'en': 'Headline',
      'hi': 'शीर्षक',
    },
    'sv7a7e6c': {
      'en': 'Short Description of what is going on...',
      'hi': 'क्या हो रहा है इसका संक्षिप्त विवरण...',
    },
    '9uyq4bq4': {
      'en': 'Admin',
      'hi': 'व्यवस्थापक',
    },
    'j4xpydpg': {
      'en': 'Electrical Department',
      'hi': 'विद्युत विभाग',
    },
    'hbcd7735': {
      'en': 'Horticulture Department',
      'hi': 'बागवानी विभाग',
    },
    'v7y898ic': {
      'en': 'Mess',
      'hi': 'गड़बड़',
    },
    '52b23n13': {
      'en': 'Civil Department',
      'hi': 'सिविल विभाग',
    },
    '6epqq178': {
      'en': 'Faculty',
      'hi': 'संकाय',
    },
    '8srvavgg': {
      'en': 'Water Mangement',
      'hi': 'जल प्रबंधन',
    },
    'm4qwmpuz': {
      'en': 'Guards',
      'hi': 'गार्ड',
    },
    'o24q1c7k': {
      'en': 'Students',
      'hi': 'छात्र',
    },
    'gtyixk9l': {
      'en': 'Which Department to Report ?',
      'hi': 'किस विभाग को रिपोर्ट करना है?',
    },
    'i7luhmud': {
      'en': 'Search for an item...',
      'hi': 'कोई आइटम खोजें...',
    },
    'n9aj3v3b': {
      'en': 'Upload Image',
      'hi': 'तस्विर अपलोड करना',
    },
    'tvuuj49d': {
      'en': 'Report',
      'hi': 'प्रतिवेदन',
    },
    'tjx0x42c': {
      'en': 'Home',
      'hi': 'होम ',
    },
  },
  // NOTIF
  {
    'twbic3mo': {
      'en': 'check.io',
      'hi': 'check.io',
    },
    '2xwajsat': {
      'en': 'Platform Navigation',
      'hi': 'प्लेटफ़ॉर्म नेविगेशन',
    },
    '9q4rmfbf': {
      'en': 'Dashboard',
      'hi': 'डैशबोर्ड',
    },
    'at9w4ezc': {
      'en': 'Chats',
      'hi': 'चैट',
    },
    'jyin17t2': {
      'en': 'Projects',
      'hi': 'परियोजनाओं',
    },
    'pek143fb': {
      'en': 'Settings',
      'hi': 'समायोजन',
    },
    'a2ysa599': {
      'en': 'Notifications',
      'hi': 'सूचनाएं',
    },
    '168k4p2o': {
      'en': '12',
      'hi': '12',
    },
    '642fqul3': {
      'en': 'Billing',
      'hi': 'बिलिंग',
    },
    '5n0ybt8n': {
      'en': 'Explore',
      'hi': 'अन्वेषण करना',
    },
    '04ze6dzj': {
      'en': 'Light Mode',
      'hi': 'लाइट मोड',
    },
    'cog06xd6': {
      'en': 'Dark Mode',
      'hi': 'डार्क मोड',
    },
    'vd7561wo': {
      'en': 'Andrew D.',
      'hi': 'एंड्रयू डी.',
    },
    '4ak31gg2': {
      'en': 'admin@gmail.com',
      'hi': 'admin@gmail.com',
    },
    'g3cpdn1q': {
      'en': 'Notifications',
      'hi': 'सूचनाएं',
    },
    'p3yszcw7': {
      'en': 'Admin 1:  ',
      'hi': 'व्यवस्थापक 1:',
    },
    '9bdiynuh': {
      'en': 'New Task Received',
      'hi': 'नया कार्य प्राप्त हुआ',
    },
    'k5f7xyfx': {
      'en': 'Task 1',
      'hi': 'कार्य 1',
    },
    '8hk0whos': {
      'en': 'FlutterFlow CRM App',
      'hi': 'फ़्लटरफ़्लो सीआरएम ऐप',
    },
    '554953wb': {
      'en': 'Jul 8, at 4:31pm',
      'hi': '8 जुलाई, शाम 4:31 बजे',
    },
    '6lydbe0q': {
      'en': 'Admin 2:  ',
      'hi': 'व्यवस्थापक 2:',
    },
    'gk64fh1l': {
      'en': 'Task Rated',
      'hi': 'कार्य रेटेड',
    },
    '0h0eyk3w': {
      'en': 'Task 2',
      'hi': 'कार्य 2',
    },
    'hg04ox8t': {
      'en': 'FlutterFlow CRM App',
      'hi': 'फ़्लटरफ़्लो सीआरएम ऐप',
    },
    'kcj6hwx9': {
      'en':
          '\"Notifications and reminders informing users about upcoming classes and training schedules will be sent to them via email, SMS or notifications within the application.\"',
      'hi':
          '\"आगामी कक्षाओं और प्रशिक्षण कार्यक्रमों के बारे में उपयोगकर्ताओं को सूचित करने वाली सूचनाएं और अनुस्मारक उन्हें ईमेल, एसएमएस या एप्लिकेशन के भीतर सूचनाओं के माध्यम से भेजे जाएंगे।\"',
    },
    'n8ti03pa': {
      'en': 'Jul 8, at 4:30pm',
      'hi': '8 जुलाई, शाम 4:30 बजे',
    },
    '8j63y5ej': {
      'en': 'Water Department:  ',
      'hi': 'जल विभाग:',
    },
    '9y016o5a': {
      'en': 'Ticket closed',
      'hi': 'टिकट बंद',
    },
    'y70wq2no': {
      'en': 'Water Leakage Solved',
      'hi': 'जल रिसाव का समाधान किया गया',
    },
    'bgjop93l': {
      'en': 'FlutterFlow CRM App',
      'hi': 'फ़्लटरफ़्लो सीआरएम ऐप',
    },
    'jkpouswr': {
      'en':
          '\"Please review the updates to this document and get back with me.\"',
      'hi':
          '\"कृपया इस दस्तावेज़ के अपडेट की समीक्षा करें और मेरे साथ वापस आएं।\"',
    },
    'asz7bdbm': {
      'en': 'Jul 8, at 2:20pm',
      'hi': '8 जुलाई, दोपहर 2:20 बजे',
    },
    'k81fcv3t': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // DASHBOARD_TASK
  {
    'tym5hv5v': {
      'en': 'Complete Early to Earn Bonus Points.',
      'hi': 'बोनस अंक अर्जित करने के लिए जल्दी पूरा करें।',
    },
    'bvd2br37': {
      'en': 'Current Tasks',
      'hi': 'वर्तमान कार्य',
    },
    'fc8odw1f': {
      'en': 'Completed Tasks',
      'hi': 'पूर्ण किये गये कार्य',
    },
    'vurry2jz': {
      'en': 'Filters',
      'hi': 'फिल्टर',
    },
    '4flb93ch': {
      'en': 'In Progress',
      'hi': 'प्रगति पर है',
    },
    'x1584pdg': {
      'en': 'Completed',
      'hi': 'पुरा होना।',
    },
    '87jlke79': {
      'en': 'Completed',
      'hi': 'पुरा होना।',
    },
    'd5x62ub5': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    '5elbopym': {
      'en': '429242424',
      'hi': '429242424',
    },
    'hq0gpk7q': {
      'en': 'Product Testing',
      'hi': 'उत्पाद का परीक्षण करना',
    },
    'jh8zo7sd': {
      'en':
          'Conduct comprehensive testing of a new product before its official release. Set up a structured testing plan, define test cases, and assign team members for various testing phases. Document bugs and issues discovered during testing...',
      'hi':
          'किसी नए उत्पाद की आधिकारिक रिलीज़ से पहले उसका व्यापक परीक्षण करें। एक संरचित परीक्षण योजना स्थापित करें, परीक्षण मामलों को परिभाषित करें, और विभिन्न परीक्षण चरणों के लिए टीम के सदस्यों को नियुक्त करें। परीक्षण के दौरान दस्तावेज़ बग और समस्याएँ पाई गईं...',
    },
    'bwtdgbuh': {
      'en': 'In Progress',
      'hi': 'प्रगति पर है',
    },
    'sm4szrp4': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    '992qfk9p': {
      'en': '429242424',
      'hi': '429242424',
    },
    'yn2rljl9': {
      'en': 'Team Training Workshop',
      'hi': 'टीम प्रशिक्षण कार्यशाला',
    },
    '8dbb017s': {
      'en':
          'Organize a training workshop for the team to enhance their skills and knowledge on a specific topic. Develop an agenda, source teaching materials, and coordinate logistics. Assign trainers and monitor attendance to ensure a successful...',
      'hi':
          'किसी विशिष्ट विषय पर टीम के कौशल और ज्ञान को बढ़ाने के लिए एक प्रशिक्षण कार्यशाला का आयोजन करें। एक एजेंडा विकसित करें, शिक्षण सामग्री प्राप्त करें और लॉजिस्टिक्स का समन्वय करें। सफल आयोजन सुनिश्चित करने के लिए प्रशिक्षक नियुक्त करें और उपस्थिति की निगरानी करें...',
    },
    '9rdz7zfb': {
      'en': 'Active',
      'hi': 'सक्रिय',
    },
    'xg72m6gh': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    'egtwksrh': {
      'en': '429242424',
      'hi': '429242424',
    },
    'flzad5yy': {
      'en': 'Budget Planning',
      'hi': 'बजट योजना',
    },
    's2ylo9w2': {
      'en':
          'Create a detailed budget plan for an upcoming project, considering all relevant expenses, such as labor costs, materials, and external services. Collaborate with the finance team to ensure accuracy and alignment with overall financial...',
      'hi':
          'श्रम लागत, सामग्री और बाहरी सेवाओं जैसे सभी प्रासंगिक खर्चों पर विचार करते हुए, आगामी परियोजना के लिए एक विस्तृत बजट योजना बनाएं। समग्र वित्तीय के साथ सटीकता और संरेखण सुनिश्चित करने के लिए वित्त टीम के साथ सहयोग करें...',
    },
    '1o7ff3o1': {
      'en': 'Active',
      'hi': 'सक्रिय',
    },
    'i3jy6cru': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    'mn315zpd': {
      'en': '429242424',
      'hi': '429242424',
    },
    '5dhhshsj': {
      'en': 'Client Onboarding Process',
      'hi': 'क्लाइंट ऑनबोर्डिंग प्रक्रिया',
    },
    'hdkkbnfx': {
      'en':
          'Develop an efficient client onboarding process that streamlines the introduction of new clients to the company\'s services. Define clear steps, create necessary templates, and assign responsible team members for each task. Monitor the completion...',
      'hi':
          'एक कुशल क्लाइंट ऑनबोर्डिंग प्रक्रिया विकसित करें जो कंपनी की सेवाओं में नए ग्राहकों के परिचय को सुव्यवस्थित करे। स्पष्ट चरणों को परिभाषित करें, आवश्यक टेम्पलेट बनाएं और प्रत्येक कार्य के लिए जिम्मेदार टीम के सदस्यों को नियुक्त करें। पूर्णता की निगरानी करें...',
    },
    'g998ivni': {
      'en': 'Active',
      'hi': 'सक्रिय',
    },
    'vnxs1c4q': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    'xn4e36q6': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    'y8x4ty6e': {
      'en': '429242424',
      'hi': '429242424',
    },
    '1n5j7fsi': {
      'en': 'Task 2',
      'hi': 'कार्य 2',
    },
    '6820qu79': {
      'en':
          'Organize a training workshop for the team to enhance their skills and knowledge on a specific topic. Develop an agenda, source teaching materials, and coordinate logistics. Assign trainers and monitor attendance to ensure a successful...',
      'hi':
          'किसी विशिष्ट विषय पर टीम के कौशल और ज्ञान को बढ़ाने के लिए एक प्रशिक्षण कार्यशाला का आयोजन करें। एक एजेंडा विकसित करें, शिक्षण सामग्री प्राप्त करें और लॉजिस्टिक्स का समन्वय करें। सफल आयोजन सुनिश्चित करने के लिए प्रशिक्षक नियुक्त करें और उपस्थिति की निगरानी करें...',
    },
    '65yq8spl': {
      'en': 'Completed',
      'hi': 'पुरा होना।',
    },
    '9cjawl8d': {
      'en': 'Current Progress',
      'hi': 'वर्तमान प्रगति',
    },
    '03ini4r7': {
      'en': 'Route progress',
      'hi': 'मार्ग प्रगति',
    },
    'vfegobeq': {
      'en': 'Tasks to be completed',
      'hi': 'कार्य पूरे होने हैं',
    },
    '4nbfz2fz': {
      'en': 'Learn Sustainible Skills',
      'hi': 'सतत कौशल सीखें',
    },
    'qemv1ygf': {
      'en': '12 Moduless',
      'hi': '12 मॉड्यूल रहित',
    },
    'nsw7hseh': {
      'en': 'Recent Activity',
      'hi': 'हाल की गतिविधि',
    },
    'b350x5l4': {
      'en': 'Below is an overview of tasks & activity completed.',
      'hi': 'नीचे पूर्ण किए गए कार्यों और गतिविधि का अवलोकन दिया गया है।',
    },
    'e740v2ru': {
      'en': 'Tasks',
      'hi': 'कार्य',
    },
    'akknodwi': {
      'en': 'Completed',
      'hi': 'पुरा होना।',
    },
    '9j8blpdd': {
      'en': 'Launches',
      'hi': 'शुरू',
    },
    'fowqyb0u': {
      'en': 'Last 30 Days',
      'hi': 'पिछले 30 दिनों में',
    },
    'tzfb9ea9': {
      'en': 'Rating',
      'hi': 'रेटिंग',
    },
    'jrk5j2oz': {
      'en': 'Task Dashboard',
      'hi': 'कार्य डैशबोर्ड',
    },
    '223x9o5p': {
      'en': 'Back',
      'hi': 'पीछे',
    },
    'bfylzr2u': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // ASSIGNED_TASK
  {
    'sd2q3ubp': {
      'en': 'Assigned Task',
      'hi': 'दिया गया काम',
    },
    'yvv5fql3': {
      'en': 'Review the details below.',
      'hi': 'नीचे दिए गए विवरण की समीक्षा करें.',
    },
    'zobfrd2v': {
      'en': 'Back',
      'hi': 'पीछे',
    },
    'azdob8kc': {
      'en': 'Filters',
      'hi': 'फिल्टर',
    },
    'bn1cuy83': {
      'en': 'In Progress',
      'hi': 'प्रगति पर है',
    },
    'gslib7ug': {
      'en': 'Completed',
      'hi': 'पुरा होना।',
    },
    'rr9rh8fk': {
      'en': 'Completed',
      'hi': 'पुरा होना।',
    },
    'nxc9x17s': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    '9ozcl3zl': {
      'en': '429242424',
      'hi': '429242424',
    },
    'qwfrsrjq': {
      'en': 'Product Testing',
      'hi': 'उत्पाद का परीक्षण करना',
    },
    '0n9auags': {
      'en':
          'Conduct comprehensive testing of a new product before its official release. Set up a structured testing plan, define test cases, and assign team members for various testing phases. Document bugs and issues discovered during testing...',
      'hi':
          'किसी नए उत्पाद की आधिकारिक रिलीज़ से पहले उसका व्यापक परीक्षण करें। एक संरचित परीक्षण योजना स्थापित करें, परीक्षण मामलों को परिभाषित करें, और विभिन्न परीक्षण चरणों के लिए टीम के सदस्यों को नियुक्त करें। परीक्षण के दौरान दस्तावेज़ बग और समस्याएँ पाई गईं...',
    },
    'uh4ap9e7': {
      'en': 'In Progress',
      'hi': 'प्रगति पर है',
    },
    '30ywftry': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    'yabmm82u': {
      'en': '429242424',
      'hi': '429242424',
    },
    'wwhovgyf': {
      'en': 'Team Training Workshop',
      'hi': 'टीम प्रशिक्षण कार्यशाला',
    },
    'h4rxo6b1': {
      'en':
          'Organize a training workshop for the team to enhance their skills and knowledge on a specific topic. Develop an agenda, source teaching materials, and coordinate logistics. Assign trainers and monitor attendance to ensure a successful...',
      'hi':
          'किसी विशिष्ट विषय पर टीम के कौशल और ज्ञान को बढ़ाने के लिए एक प्रशिक्षण कार्यशाला का आयोजन करें। एक एजेंडा विकसित करें, शिक्षण सामग्री प्राप्त करें और लॉजिस्टिक्स का समन्वय करें। सफल आयोजन सुनिश्चित करने के लिए प्रशिक्षक नियुक्त करें और उपस्थिति की निगरानी करें...',
    },
    'df5spd2i': {
      'en': 'Active',
      'hi': 'सक्रिय',
    },
    '5i1rj2hx': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    'lh8ekhdy': {
      'en': '429242424',
      'hi': '429242424',
    },
    'f0akg86p': {
      'en': 'Budget Planning',
      'hi': 'बजट योजना',
    },
    'kcqg8kg9': {
      'en':
          'Create a detailed budget plan for an upcoming project, considering all relevant expenses, such as labor costs, materials, and external services. Collaborate with the finance team to ensure accuracy and alignment with overall financial...',
      'hi':
          'श्रम लागत, सामग्री और बाहरी सेवाओं जैसे सभी प्रासंगिक खर्चों पर विचार करते हुए, आगामी परियोजना के लिए एक विस्तृत बजट योजना बनाएं। समग्र वित्तीय के साथ सटीकता और संरेखण सुनिश्चित करने के लिए वित्त टीम के साथ सहयोग करें...',
    },
    '2hban1o8': {
      'en': 'Active',
      'hi': 'सक्रिय',
    },
    'is16mm7g': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    '7rflbmk9': {
      'en': '429242424',
      'hi': '429242424',
    },
    'mssb1hny': {
      'en': 'Client Onboarding Process',
      'hi': 'क्लाइंट ऑनबोर्डिंग प्रक्रिया',
    },
    'ssjdj9ot': {
      'en':
          'Develop an efficient client onboarding process that streamlines the introduction of new clients to the company\'s services. Define clear steps, create necessary templates, and assign responsible team members for each task. Monitor the completion...',
      'hi':
          'एक कुशल क्लाइंट ऑनबोर्डिंग प्रक्रिया विकसित करें जो कंपनी की सेवाओं में नए ग्राहकों के परिचय को सुव्यवस्थित करे। स्पष्ट चरणों को परिभाषित करें, आवश्यक टेम्पलेट बनाएं और प्रत्येक कार्य के लिए जिम्मेदार टीम के सदस्यों को नियुक्त करें। पूर्णता की निगरानी करें...',
    },
    '9dx1gd52': {
      'en': 'Active',
      'hi': 'सक्रिय',
    },
    'lsg113yi': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    'nsbgudrc': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    'vora1l1f': {
      'en': '429242424',
      'hi': '429242424',
    },
    'k4e322bm': {
      'en': 'Task 2',
      'hi': 'कार्य 2',
    },
    'd5sr87bq': {
      'en':
          'Organize a training workshop for the team to enhance their skills and knowledge on a specific topic. Develop an agenda, source teaching materials, and coordinate logistics. Assign trainers and monitor attendance to ensure a successful...',
      'hi':
          'किसी विशिष्ट विषय पर टीम के कौशल और ज्ञान को बढ़ाने के लिए एक प्रशिक्षण कार्यशाला का आयोजन करें। एक एजेंडा विकसित करें, शिक्षण सामग्री प्राप्त करें और लॉजिस्टिक्स का समन्वय करें। सफल आयोजन सुनिश्चित करने के लिए प्रशिक्षक नियुक्त करें और उपस्थिति की निगरानी करें...',
    },
    'e9zc1r45': {
      'en': 'Completed',
      'hi': 'पुरा होना।',
    },
    'fmpkxw42': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // MEMBERS
  {
    'wzk1r1zg': {
      'en': 'Members',
      'hi': 'सदस्यों',
    },
    'apiafi6q': {
      'en': 'Below are a list of members of your team.',
      'hi': 'आपकी टीम के सदस्यों की सूची नीचे दी गई है.',
    },
    'd3rvrckg': {
      'en': 'Search all users...',
      'hi': 'सभी उपयोगकर्ता खोजें...',
    },
    'jsgp4eg1': {
      'en': 'All',
      'hi': 'सभी',
    },
    '0tm60xzg': {
      'en': 'All',
      'hi': 'सभी',
    },
    'gjqh5i7c': {
      'en': 'All',
      'hi': 'सभी',
    },
    '9t0e8xdb': {
      'en': 'Name',
      'hi': 'नाम',
    },
    '7r29aso2': {
      'en': 'Last Active',
      'hi': 'अंतिम सक्रिय',
    },
    'et1516qr': {
      'en': 'Title',
      'hi': 'शीर्षक',
    },
    'vax2jvla': {
      'en': 'Role',
      'hi': 'भूमिका',
    },
    't3tsv2t3': {
      'en': '5 mins ago',
      'hi': '5 मिनट पहले',
    },
    'dn8x104y': {
      'en': 'Head of Design',
      'hi': 'डिज़ाइन प्रमुख',
    },
    'hqyybhuc': {
      'en': 'Nipun Agrawal',
      'hi': 'निपुण अग्रवाल',
    },
    'j7nvth0i': {
      'en': 'Bakshi@gmail.com',
      'hi': 'Buckshi@gmail.com',
    },
    'wkwq68j4': {
      'en': '5 mins ago',
      'hi': '5 मिनट पहले',
    },
    'v636guiy': {
      'en': 'Head of Design',
      'hi': 'डिज़ाइन प्रमुख',
    },
    '39wwhsuf': {
      'en': 'Viewer',
      'hi': 'दर्शक',
    },
    '37c7sh57': {
      'en': 'Nipun Agrawal',
      'hi': 'निपुण अग्रवाल',
    },
    'u89mgzxg': {
      'en': 'Bakshi@gmail.com',
      'hi': 'Buckshi@gmail.com',
    },
    'br990jwd': {
      'en': '5 mins ago',
      'hi': '5 मिनट पहले',
    },
    '7ir4bmas': {
      'en': 'Head of Design',
      'hi': 'डिज़ाइन प्रमुख',
    },
    'ghf90bfb': {
      'en': 'Viewer',
      'hi': 'दर्शक',
    },
    'xs58msvx': {
      'en': 'Nipun Agrawal',
      'hi': 'निपुण अग्रवाल',
    },
    'b0jxemib': {
      'en': 'Bakshi@gmail.com',
      'hi': 'Buckshi@gmail.com',
    },
    'yv3m7mqf': {
      'en': '5 mins ago',
      'hi': '5 मिनट पहले',
    },
    'pf0yc0vx': {
      'en': 'Head of Design',
      'hi': 'डिज़ाइन प्रमुख',
    },
    'r629yrdt': {
      'en': 'Viewer',
      'hi': 'दर्शक',
    },
    'xbdiwiol': {
      'en': 'Nipun Agrawal',
      'hi': 'निपुण अग्रवाल',
    },
    '9e5o16gw': {
      'en': 'Bakshi@gmail.com',
      'hi': 'Buckshi@gmail.com',
    },
    '66zusisg': {
      'en': '5 mins ago',
      'hi': '5 मिनट पहले',
    },
    'ez9lpiru': {
      'en': 'Head of Design',
      'hi': 'डिज़ाइन प्रमुख',
    },
    'c4svqezx': {
      'en': 'Admin',
      'hi': 'व्यवस्थापक',
    },
    '3ivdx6w6': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // LEARNING
  {
    'x80dmc3v': {
      'en': 'Description',
      'hi': 'विवरण',
    },
    '318y9ybm': {
      'en': 'FlutterFlow Design Basics',
      'hi': 'फ़्लटरफ़्लो डिज़ाइन मूल बातें',
    },
    'v8o95jiw': {
      'en': 'Class Details',
      'hi': 'कक्षा विवरण',
    },
    '2cwldyc6': {
      'en':
          'Experience the power of Supabase\'s real-time database and authentication services combined with intuitive visual design using FlutterFlow, significantly simplifying the app development process while delivering feature-rich, high-performance applications. This integration makes it possible to create visually stunning, data-driven apps with ease and speed.',
      'hi':
          'फ़्लटरफ़्लो का उपयोग करके सहज दृश्य डिज़ाइन के साथ संयुक्त सुपाबेस के वास्तविक समय डेटाबेस और प्रमाणीकरण सेवाओं की शक्ति का अनुभव करें, जो सुविधा-संपन्न, उच्च-प्रदर्शन अनुप्रयोगों को वितरित करते हुए ऐप विकास प्रक्रिया को काफी सरल बनाता है। यह एकीकरण आसानी और गति के साथ दृश्य रूप से आश्चर्यजनक, डेटा-संचालित ऐप्स बनाना संभव बनाता है।',
    },
    'jimz75c0': {
      'en': 'Class Content',
      'hi': 'कक्षा सामग्री',
    },
    'llb8u7ta': {
      'en': 'Intro to UX Design',
      'hi': 'यूएक्स डिज़ाइन का परिचय',
    },
    'av0yrvk0': {
      'en': 'A short history into what UX design is and the history of it.',
      'hi': 'UX डिज़ाइन क्या है और इसके इतिहास का एक संक्षिप्त इतिहास।',
    },
    'oyqmo58r': {
      'en': '8 mins',
      'hi': '8 मिनट',
    },
    'k9lsx099': {
      'en': 'Intro to UX Design',
      'hi': 'यूएक्स डिज़ाइन का परिचय',
    },
    'ihia3cxv': {
      'en': 'A short history into what UX design is and the history of it.',
      'hi': 'UX डिज़ाइन क्या है और इसके इतिहास का एक संक्षिप्त इतिहास।',
    },
    'c4f5ye65': {
      'en': '8 mins',
      'hi': '8 मिनट',
    },
    'vm7smvpx': {
      'en': 'Intro to UX Design',
      'hi': 'यूएक्स डिज़ाइन का परिचय',
    },
    'lxebp1m0': {
      'en': 'A short history into what UX design is and the history of it.',
      'hi': 'UX डिज़ाइन क्या है और इसके इतिहास का एक संक्षिप्त इतिहास।',
    },
    'wbq2ddkr': {
      'en': '8 mins',
      'hi': '8 मिनट',
    },
    'mx02bstv': {
      'en': 'Intro to UX Design',
      'hi': 'यूएक्स डिज़ाइन का परिचय',
    },
    'a4sw5rw4': {
      'en': 'A short history into what UX design is and the history of it.',
      'hi': 'UX डिज़ाइन क्या है और इसके इतिहास का एक संक्षिप्त इतिहास।',
    },
    's92viskz': {
      'en': '8 mins',
      'hi': '8 मिनट',
    },
    'f9t36f0q': {
      'en': 'Enroll in Class',
      'hi': 'कक्षा में नामांकन करें',
    },
    '00mwhtlk': {
      'en': 'Favorite Class',
      'hi': 'पसंदीदा क्लास',
    },
    '17zw7q3s': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // TASK_SUBMIT
  {
    '7qyt3157': {
      'en': 'Upload Progress',
      'hi': 'प्रगति अपलोड करें',
    },
    '7uifpz68': {
      'en': 'Progress .......',
      'hi': 'प्रगति .......',
    },
    '8w5t6bhv': {
      'en': 'Due',
      'hi': 'देय',
    },
    'ketxtycx': {
      'en': 'Upload Task',
      'hi': 'कार्य अपलोड करें',
    },
    '9bv6c6si': {
      'en': 'Task Members',
      'hi': 'कार्य सदस्य',
    },
    'w5z0twwi': {
      'en': 'Debpratim',
      'hi': 'देबप्रतिम',
    },
    '66hej6zh': {
      'en': 'dabpratim@gmail.com',
      'hi': 'dabpratim@gmail.com',
    },
    '0rsxfeas': {
      'en': 'Submit',
      'hi': 'जमा करना',
    },
    'm39vuqds': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // Create_tas
  {
    '9z28i4dh': {
      'en': 'Assigned Task',
      'hi': 'दिया गया काम',
    },
    'kicfqqip': {
      'en': 'Create Task',
      'hi': 'कार्य बनाएँ',
    },
    'ou77fbmf': {
      'en': 'Task  Title.......',
      'hi': 'कार्य का शीर्षक.......',
    },
    'i9bc4tw4': {
      'en': 'Task  Description.......',
      'hi': 'कार्य विवरण.......',
    },
    'kj9xxfup': {
      'en': 'Set a Deadline',
      'hi': 'एक समय सीमा निर्धारित करें',
    },
    'mf6iw2y0': {
      'en': 'Upload Photo Related to Task',
      'hi': 'कार्य से संबंधित फोटो अपलोड करें',
    },
    'ztvwpzmw': {
      'en': 'Please select...',
      'hi': 'कृपया चयन कीजिए...',
    },
    'kctond6s': {
      'en': 'Search for an item...',
      'hi': 'कोई आइटम खोजें...',
    },
    'q75sgess': {
      'en': 'Create',
      'hi': 'बनाएं',
    },
    'x572zzjc': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // evaluate
  {
    'mujf5yfl': {
      'en': 'Task  Progress',
      'hi': 'कार्य प्रगति',
    },
    'sogxi2w0': {
      'en': 'Share',
      'hi': 'शेयर करना',
    },
    'xcow4b0u': {
      'en': 'Evaluate',
      'hi': 'मूल्यांकन करना',
    },
    'gcsrr0t5': {
      'en': 'Any Feedback....',
      'hi': 'कोई प्रतिपुष्टि....',
    },
    'q3hh8902': {
      'en': 'Need to upload!',
      'hi': 'अपलोड करने की आवश्यकता है!',
    },
    '5k2kvd1c': {
      'en': 'Submit',
      'hi': 'जमा करना',
    },
    '57g3ivx7': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // Action_DESCRIPTION
  {
    'bwpd398w': {
      'en': 'Challenge Description',
      'hi': 'चुनौती विवरण',
    },
    '8josn7ml': {
      'en': 'Overview',
      'hi': 'अवलोकन',
    },
    'gunvhjyt': {
      'en': 'EcoBrick Challenge',
      'hi': 'इकोब्रिक चैलेंज',
    },
    'w2mm5lnv': {
      'en': 'Deatils',
      'hi': 'विवरण',
    },
    'f8y74fxz': {
      'en':
          '• Collect flexible plastic packaging, polythene bags and other non- recyclable plastics and a PET Plastic bottle.\n• Stuff the collected plastic into the bottle with the help of a stick or pencil and close the bottle cap tighly.\n• Cutting the plastic into smaller pieces is highly recommended as it enables stuffing of more plastic which results into a good quality Ecobrick.\n• Please ensure the plastic is clean or rinsed and dry.\n• Do not add any biodegradable material into the bottle or it may rot\nand create gas in it.\n• This Ecobrickcan be used for making civil structures like garden wall, tanks, etc.\n• Click and upload a picture of the Ecobrick once fully made.',
      'hi':
          '• लचीली प्लास्टिक पैकेजिंग, पॉलिथीन बैग और अन्य गैर-पुनर्चक्रण योग्य प्लास्टिक और एक पीईटी प्लास्टिक की बोतल इकट्ठा करें।\n• एकत्रित प्लास्टिक को किसी छड़ी या पेंसिल की सहायता से बोतल में भरें और बोतल का ढक्कन कसकर बंद कर दें।\n• प्लास्टिक को छोटे टुकड़ों में काटने की अत्यधिक अनुशंसा की जाती है क्योंकि इससे अधिक प्लास्टिक भरने में मदद मिलती है जिसके परिणामस्वरूप अच्छी गुणवत्ता वाली इकोब्रिक बनती है।\n• कृपया सुनिश्चित करें कि प्लास्टिक साफ या धुला हुआ और सूखा हो।\n• बोतल में कोई बायोडिग्रेडेबल सामग्री न डालें अन्यथा यह सड़ सकती है\nऔर उसमें गैस बनाएं.\n• इस इकोब्रिक का उपयोग बगीचे की दीवार, टैंक आदि जैसी नागरिक संरचनाओं को बनाने के लिए किया जा सकता है।\n• इकोब्रिक पूरी तरह बन जाने पर उसकी एक तस्वीर क्लिक करें और अपलोड करें।',
    },
    'np7fzqlr': {
      'en': 'Benefits',
      'hi': 'फ़ायदे',
    },
    'v679kste': {
      'en':
          'Engaging in the Ecobrick challenge promotes upcycling by fostering the concept of Circular Economy. It creates a sense of social responsibility. In the bigger picture it reduces the extent of non biodegradable material from going into the landfill.',
      'hi':
          'इकोब्रिक चुनौती में शामिल होने से सर्कुलर इकोनॉमी की अवधारणा को बढ़ावा देकर अपसाइक्लिंग को बढ़ावा मिलता है। यह सामाजिक उत्तरदायित्व की भावना पैदा करता है। बड़ी तस्वीर में यह लैंडफिल में जाने से गैर-बायोडिग्रेडेबल सामग्री की सीमा को कम कर देता है।',
    },
    '3t131eac': {
      'en': 'What will you earn?\n50 Green Points on completing one challenge',
      'hi': 'क्या कमाओगे?\nएक चुनौती पूरी करने पर 50 ग्रीन पॉइंट',
    },
    '2guhs7xo': {
      'en': 'Upload Image',
      'hi': 'तस्विर अपलोड करना',
    },
    'hptkcjck': {
      'en': 'Accept',
      'hi': 'स्वीकार करना',
    },
    'ghn4p6ys': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // volunteer
  {
    'rsn9a0c9': {
      'en': 'Details',
      'hi': 'विवरण',
    },
    'cgtc06qn': {
      'en':
          'By protecting and preserving our oceans, we can effectively reduce global warming as healthy oceans absorb a significant amount of atmospheric carbon dioxide. Implementing measures to prevent overfishing, reducing plastic pollution, and conserving marine habitats will contribute to a balanced ocean ecosystem, ultimately mitigating global warming.',
      'hi':
          'अपने महासागरों की सुरक्षा और संरक्षण करके, हम ग्लोबल वार्मिंग को प्रभावी ढंग से कम कर सकते हैं क्योंकि स्वस्थ महासागर वायुमंडलीय कार्बन डाइऑक्साइड की एक महत्वपूर्ण मात्रा को अवशोषित करते हैं। अत्यधिक मछली पकड़ने को रोकने, प्लास्टिक प्रदूषण को कम करने और समुद्री आवासों को संरक्षित करने के उपायों को लागू करने से एक संतुलित महासागर पारिस्थितिकी तंत्र में योगदान मिलेगा, जो अंततः ग्लोबल वार्मिंग को कम करेगा।',
    },
    '06pz0n87': {
      'en': 'Start Date',
      'hi': 'आरंभ करने की तिथि',
    },
    'wfix3qio': {
      'en': 'End  Date',
      'hi': 'अंतिम तिथि',
    },
    '8p1kdy59': {
      'en': 'Address',
      'hi': 'पता',
    },
    '9ovzwxg5': {
      'en': 'Volunteers',
      'hi': 'स्वयंसेवकों',
    },
    '3i5onvac': {
      'en': 'What You Will Get?',
      'hi': 'आपको क्या मिलेगा?',
    },
    'mxnpb7eg': {
      'en': '- 50 Green Points\n- Certificate of Volunteering',
      'hi': '- 50 हरित अंक\n- स्वयंसेवा का प्रमाणपत्र',
    },
    'rg4f2c7i': {
      'en': 'Volunteer',
      'hi': 'स्वयंसेवक',
    },
    '78ss6lvn': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // leaderboard
  {
    'ry8mrsj6': {
      'en': 'Level 1',
      'hi': 'स्तर 1',
    },
    'udfxk0ww': {
      'en': 'Seedling Start',
      'hi': 'अंकुर प्रारंभ',
    },
    '6dzt721d': {
      'en': 'Level 2',
      'hi': 'लेवल 2',
    },
    'z4ask0yu': {
      'en': 'Budding',
      'hi': 'नवोदित',
    },
    'r7syaa3j': {
      'en': 'Level 3',
      'hi': 'स्तर 3',
    },
    'mwlc1xyo': {
      'en': 'Seedling Start',
      'hi': 'अंकुर प्रारंभ',
    },
    '5irp7omm': {
      'en': 'Level 4',
      'hi': 'लेवल 4',
    },
    'lkyfmcdv': {
      'en': 'Seedling Start',
      'hi': 'अंकुर प्रारंभ',
    },
    'hhbonalu': {
      'en': 'Level 5',
      'hi': 'स्तर 5',
    },
    'udofusme': {
      'en': 'Seedling Start',
      'hi': 'अंकुर प्रारंभ',
    },
    'lpk4tl8l': {
      'en': 'Level 6',
      'hi': 'स्तर 6',
    },
    '3bu7ljdt': {
      'en': 'Seedling Start',
      'hi': 'अंकुर प्रारंभ',
    },
    '2l0yr1vv': {
      'en': 'Sunny Kumar\n3066',
      'hi': 'सन्नी कुमार\n3066',
    },
    '2e3xx28z': {
      'en': '1500 Points',
      'hi': '1500 अंक',
    },
    'za8eu766': {
      'en': '5',
      'hi': '5',
    },
    'l9zvknvw': {
      'en': 'All Leaderboard',
      'hi': 'सभी लीडरबोर्ड',
    },
    'ptzqkan9': {
      'en': 'Debpratim\n3065',
      'hi': 'देबप्रतिम\n3065',
    },
    'jq2ua3ej': {
      'en': '4000 Points',
      'hi': '4000 अंक',
    },
    '2fi9ufus': {
      'en': '1',
      'hi': '1',
    },
    'nlbleteo': {
      'en': 'Pulkit\n2027',
      'hi': 'पुलकित\n2027',
    },
    'm4csnng8': {
      'en': '3000 Points',
      'hi': '3000 अंक',
    },
    'm1ywlode': {
      'en': '2',
      'hi': '2',
    },
    'xc23yp3z': {
      'en': 'Bakshi\n2001',
      'hi': 'बख्शी\n2001',
    },
    'x0o4lu9j': {
      'en': '2000 Points',
      'hi': '2000 अंक',
    },
    'u1uy9hzt': {
      'en': '4',
      'hi': '4',
    },
    '7vldgaes': {
      'en': 'Nipun\n3068',
      'hi': 'निपुण\n3068',
    },
    'poa7d8np': {
      'en': '1900 Points',
      'hi': '1900 अंक',
    },
    'y5b78dls': {
      'en': '1',
      'hi': '1',
    },
    'vatmx9yg': {
      'en': 'Reviews',
      'hi': 'समीक्षा',
    },
    'po8qp4te': {
      'en': 'Admin 1',
      'hi': 'व्यवस्थापक 1',
    },
    'z2efrnhm': {
      'en': 'user@domainname.com',
      'hi': 'user@domainname.com',
    },
    'o1bdh5j6': {
      'en': 'Overall',
      'hi': 'कुल मिलाकर',
    },
    'heozhn74': {
      'en': '5',
      'hi': '5',
    },
    '8iu3hopt': {
      'en':
          '\"Excellent work on the recent project! Your dedication and attention to detail were impressive, leading to a well-executed and thoughtful outcome. Keep up the great work!\"',
      'hi':
          '\"हालिया परियोजना पर उत्कृष्ट कार्य! आपका समर्पण और विस्तार पर ध्यान प्रभावशाली था, जिससे एक अच्छी तरह से क्रियान्वित और विचारशील परिणाम प्राप्त हुआ। महान कार्य जारी रखें!\"',
    },
    'ulyoaacl': {
      'en': 'Admin 2',
      'hi': 'व्यवस्थापक 2',
    },
    'pqf745dp': {
      'en': 'user@domainname.com',
      'hi': 'user@domainname.com',
    },
    'udrkucz3': {
      'en': 'Overall',
      'hi': 'कुल मिलाकर',
    },
    'ub034yip': {
      'en': '5',
      'hi': '5',
    },
    'ln4g749r': {
      'en':
          '\"Excellent work on the recent project! Your dedication and attention to detail were impressive, leading to a well-executed and thoughtful outcome. Keep up the great work!\"',
      'hi':
          '\"हालिया परियोजना पर उत्कृष्ट कार्य! आपका समर्पण और विस्तार पर ध्यान प्रभावशाली था, जिससे एक अच्छी तरह से क्रियान्वित और विचारशील परिणाम प्राप्त हुआ। महान कार्य जारी रखें!\"',
    },
    'hrhhuzqf': {
      'en': 'Leaderboard',
      'hi': 'लीडरबोर्ड',
    },
    '2xbt0ty6': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // viewtaskimageforteacher
  {
    'mxe8ve88': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // statistics
  {
    '3npldf1h': {
      'en': 'My Statistics',
      'hi': 'मेरे आँकड़े',
    },
    'kkdkj18d': {
      'en': 'Recent Activity',
      'hi': 'हाल की गतिविधि',
    },
    '92cjjojk': {
      'en': 'Below is an overview of tasks & activity completed.',
      'hi': 'नीचे पूर्ण किए गए कार्यों और गतिविधि का अवलोकन दिया गया है।',
    },
    'vfc4b6ds': {
      'en': 'This week',
      'hi': 'इस सप्ताह',
    },
    'skj1w0xj': {
      'en': 'Month',
      'hi': 'महीना',
    },
    '2oe96juv': {
      'en': 'Year',
      'hi': 'वर्ष',
    },
    'gv36xdv0': {
      'en': 'Last 30 Days',
      'hi': 'पिछले 30 दिनों में',
    },
    'dgsy6olf': {
      'en': 'Points',
      'hi': 'अंक',
    },
    'w0kt59b8': {
      'en': 'Tasks',
      'hi': 'कार्य',
    },
    'o0kajsz4': {
      'en': '11',
      'hi': '11',
    },
    'loyaezfn': {
      'en': 'Lifetime Points',
      'hi': 'आजीवन अंक',
    },
    'nkqcbqis': {
      'en': '11',
      'hi': '11',
    },
    'e5xqhvyp': {
      'en': 'Challenges',
      'hi': 'चुनौतियां',
    },
    '9t5rxb62': {
      'en': '11',
      'hi': '11',
    },
    'oou60jcu': {
      'en': 'Top 3 positions',
      'hi': 'शीर्ष 3 स्थान',
    },
    'mktfbuqa': {
      'en': '11',
      'hi': '11',
    },
    '43tdh7gx': {
      'en': 'Volunteered',
      'hi': 'स्वेच्छा',
    },
    'fgd24hza': {
      'en': '11',
      'hi': '11',
    },
    'j5opx0y9': {
      'en': 'Gentleman',
      'hi': 'सज्जन',
    },
    '3fmle0nf': {
      'en': '11',
      'hi': '11',
    },
    '330hbs21': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // community
  {
    '0kcfaf3s': {
      'en': 'Sunny Kumar',
      'hi': 'सन्नी कुमार',
    },
    'lz5k3ams': {
      'en': '3.1k Members',
      'hi': '3.1k सदस्य',
    },
    '5uqu8y2a': {
      'en': 'What is in your mind ?',
      'hi': 'आपके मस्तिष्क में क्या चल रहा है ?',
    },
    'dya5k2i2': {
      'en': 'Upload Media',
      'hi': 'मीडिया अपलोड करें',
    },
    'nihvfwr0': {
      'en': 'Sunny Kumar',
      'hi': 'सन्नी कुमार',
    },
    'kdyl7ktg': {
      'en': '1m ago',
      'hi': '1 मी पहले',
    },
    '76txm60x': {
      'en':
          'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
      'hi':
          'लोरेम इप्सम डोलोर सिट अमेट, कंसेक्टेचर एडिपिसिंग एलीट, सेड डू ईयसमॉड टेम्पोर इंसिडिडंट यूट लेबोर एट डोलोर मैग्ना अलिका। यूटी एनिम एड मिनिम वेनियम, क्विस नोस्ट्रुड एक्सर्सिटेशन उल्लामको लेबोरिस निसी यूटी एलिक्विप एक्स ईए कमोडो कॉन्सक्वेट।',
    },
    'bywppsw4': {
      'en': '3',
      'hi': '3',
    },
    '02qsv0mg': {
      'en': 'likes',
      'hi': 'पसंद है',
    },
    'lahgtsq9': {
      'en': '8',
      'hi': '8',
    },
    '9975gn0m': {
      'en': 'Comments',
      'hi': 'टिप्पणियाँ',
    },
    '8e00hy2d': {
      'en': 'Aditya',
      'hi': 'आदित्य',
    },
    's9cy1i9r': {
      'en':
          'I\'m not really sure about this section here aI think you should do soemthing cool!',
      'hi':
          'मैं यहां इस अनुभाग के बारे में वास्तव में निश्चित नहीं हूं, मुझे लगता है कि आपको कुछ अच्छा करना चाहिए!',
    },
    'ft2b34e2': {
      'en': 'a min ago',
      'hi': 'एक मिनट पहले',
    },
    'iuz3y06t': {
      'en': 'Sandra Smith',
      'hi': 'सैंड्रा स्मिथ',
    },
    '9tg9bwe9': {
      'en':
          'I\'m not really sure about this section here aI think you should do soemthing cool!',
      'hi':
          'मैं यहां इस अनुभाग के बारे में वास्तव में निश्चित नहीं हूं, मुझे लगता है कि आपको कुछ अच्छा करना चाहिए!',
    },
    'lafq0fa2': {
      'en': 'a min ago',
      'hi': 'एक मिनट पहले',
    },
    's18tqso0': {
      'en': 'Send Post',
      'hi': 'पोस्ट भेजें',
    },
    'kv36nm4m': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // login
  {
    '501c9aga': {
      'en': 'Harit Parishar',
      'hi': 'हरित परिषर',
    },
    '5zqe02h3': {
      'en': 'Welcome Back',
      'hi': 'वापसी पर स्वागत है',
    },
    'kw57t8k6': {
      'en': 'Fill out the information below in order to access your account.',
      'hi': 'अपने खाते तक पहुंचने के लिए नीचे दी गई जानकारी भरें।',
    },
    'o0fyecdz': {
      'en': 'Email',
      'hi': 'ईमेल',
    },
    'czafgmpz': {
      'en': 'Password',
      'hi': 'पासवर्ड',
    },
    'efnuoxxd': {
      'en': 'Sign In',
      'hi': 'दाखिल करना',
    },
    't6i3hnym': {
      'en': 'Or sign in with',
      'hi': 'या इसके साथ साइन इन करें',
    },
    '0flx7lop': {
      'en': 'Continue with Google',
      'hi': 'Google के साथ जारी रखें',
    },
    'hugz8yqs': {
      'en': 'Continue with Apple',
      'hi': 'एप्पल के साथ जारी रखें',
    },
    'nydahubi': {
      'en': 'Don\'t have an account?  ',
      'hi': 'कोई खाता नहीं है?',
    },
    'swgjp3am': {
      'en': 'Sign Up here',
      'hi': 'यहां साइन अप करें',
    },
    'mgu0rkua': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // create_acc
  {
    '82dcoftx': {
      'en': 'Harit Parishar',
      'hi': 'हरित परिषर',
    },
    'e7nuzy08': {
      'en': 'Starting Now!',
      'hi': 'अब प्रारंभ कर रहा है!',
    },
    'cmzmm3kv': {
      'en': 'AISHE Code',
      'hi': 'एआईएसएचई कोड',
    },
    'f9xda0oh': {
      'en': 'Email',
      'hi': 'ईमेल',
    },
    '1dwuoxlu': {
      'en': 'Name',
      'hi': 'नाम',
    },
    '1s1zmsmp': {
      'en': 'Password',
      'hi': 'पासवर्ड',
    },
    '7cbjg4uw': {
      'en': 'Civil Department',
      'hi': 'सिविल विभाग',
    },
    '96x00qau': {
      'en': 'Electrical Department',
      'hi': 'विद्युत विभाग',
    },
    'fchjslqw': {
      'en': 'Faculty',
      'hi': 'संकाय',
    },
    'j3f8k2hx': {
      'en': 'Horticulture Department',
      'hi': 'बागवानी विभाग',
    },
    '335hjnrz': {
      'en': 'Mess Council',
      'hi': 'मेस काउंसिल',
    },
    'r72pwkgb': {
      'en': 'Security',
      'hi': 'सुरक्षा',
    },
    'hzess66x': {
      'en': 'Student',
      'hi': 'विद्यार्थी',
    },
    '5ob9he98': {
      'en': 'Water Department',
      'hi': 'जल विभाग',
    },
    'gxy7hwcs': {
      'en': 'Select Your Role....',
      'hi': 'अपनी भूमिका चुनें....',
    },
    'xq67v9mc': {
      'en': 'Search for an item...',
      'hi': 'कोई आइटम खोजें...',
    },
    '4q8dwwk3': {
      'en': 'Create Account',
      'hi': 'खाता बनाएं',
    },
    '3x8z0xnp': {
      'en': 'Or create with',
      'hi': 'या साथ बनाएं',
    },
    'k92mnpe6': {
      'en': 'Continue with Google',
      'hi': 'Google के साथ जारी रखें',
    },
    '3qgllcv6': {
      'en': 'Continue with Apple',
      'hi': 'एप्पल के साथ जारी रखें',
    },
    '4w290sxg': {
      'en': 'Already have an Account?',
      'hi': 'क्या आपके पास पहले से एक खाता मौजूद है?',
    },
    '3ashli1i': {
      'en': 'Sign In here',
      'hi': 'यहां साइन इन करो',
    },
    'wkh14d9n': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // campus1
  {
    'uksoi9x2': {
      'en': 'Location-Based Services',
      'hi': 'स्थान आधारित सेवाएं',
    },
    'duuxpznm': {
      'en': 'Recycling Centers',
      'hi': 'पुनर्चक्रण केंद्र',
    },
    '3iydvcup': {
      'en': 'Find the nearest recycling centers in your area.',
      'hi': 'अपने क्षेत्र में निकटतम पुनर्चक्रण केंद्र खोजें।',
    },
    '25monr8g': {
      'en': 'Find Recycling Centers',
      'hi': 'पुनर्चक्रण केंद्र खोजें',
    },
    'j5qm1k01': {
      'en': 'Environmental Centers',
      'hi': 'पर्यावरण केंद्र',
    },
    'plsl0uzh': {
      'en': 'Discover local environmental events happening near you.',
      'hi': 'अपने आस-पास होने वाली स्थानीय पर्यावरणीय घटनाओं की खोज करें।',
    },
    'x45j7exg': {
      'en': 'Find Environmental Events',
      'hi': 'पर्यावरणीय घटनाएँ खोजें',
    },
    'oomwmyut': {
      'en': 'Areas Needing Cleanup',
      'hi': 'सफाई की आवश्यकता वाले क्षेत्र',
    },
    'k4vou9lz': {
      'en': 'Join community efforts to clean up and improve your local areas.',
      'hi':
          'अपने स्थानीय क्षेत्रों की सफ़ाई और सुधार के लिए सामुदायिक प्रयासों में शामिल हों।',
    },
    'aee9hxrx': {
      'en': 'Find Cleanup Areas',
      'hi': 'सफ़ाई क्षेत्र खोजें',
    },
    'keetlty5': {
      'en': 'Location-Based Services',
      'hi': 'स्थान आधारित सेवाएं',
    },
  },
  // TaskEvaluationForStudent
  {
    'f64j7dno': {
      'en': 'Task Result',
      'hi': 'कार्य परिणाम',
    },
    '3qf9sibm': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // ViewReports
  {
    'pq494d81': {
      'en': 'Alerts For You...',
      'hi': 'आपके लिए अलर्ट...',
    },
    '2y3rzcf5': {
      'en': 'Review the details below.',
      'hi': 'नीचे दिए गए विवरण की समीक्षा करें.',
    },
    'ner00g1o': {
      'en': 'Back',
      'hi': 'पीछे',
    },
    '2zuiksda': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    'wxm5p3nx': {
      'en': '429242424',
      'hi': '429242424',
    },
    'wk01p4vf': {
      'en': 'Product Testing',
      'hi': 'उत्पाद का परीक्षण करना',
    },
    '09a8nupy': {
      'en':
          'Conduct comprehensive testing of a new product before its official release. Set up a structured testing plan, define test cases, and assign team members for various testing phases. Document bugs and issues discovered during testing...',
      'hi':
          'किसी नए उत्पाद की आधिकारिक रिलीज़ से पहले उसका व्यापक परीक्षण करें। एक संरचित परीक्षण योजना स्थापित करें, परीक्षण मामलों को परिभाषित करें, और विभिन्न परीक्षण चरणों के लिए टीम के सदस्यों को नियुक्त करें। परीक्षण के दौरान दस्तावेज़ बग और समस्याएँ पाई गईं...',
    },
    'zi1kwhem': {
      'en': 'In Progress',
      'hi': 'प्रगति पर है',
    },
    'xhb6r2qe': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    '96aiucar': {
      'en': '429242424',
      'hi': '429242424',
    },
    'c5ycy8yz': {
      'en': 'Team Training Workshop',
      'hi': 'टीम प्रशिक्षण कार्यशाला',
    },
    '7wegijbc': {
      'en':
          'Organize a training workshop for the team to enhance their skills and knowledge on a specific topic. Develop an agenda, source teaching materials, and coordinate logistics. Assign trainers and monitor attendance to ensure a successful...',
      'hi':
          'किसी विशिष्ट विषय पर टीम के कौशल और ज्ञान को बढ़ाने के लिए एक प्रशिक्षण कार्यशाला का आयोजन करें। एक एजेंडा विकसित करें, शिक्षण सामग्री प्राप्त करें और लॉजिस्टिक्स का समन्वय करें। सफल आयोजन सुनिश्चित करने के लिए प्रशिक्षक नियुक्त करें और उपस्थिति की निगरानी करें...',
    },
    'sms38wv3': {
      'en': 'Active',
      'hi': 'सक्रिय',
    },
    '9ac5g4rd': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    'bje6zvqq': {
      'en': '429242424',
      'hi': '429242424',
    },
    '99is1aeo': {
      'en': 'Budget Planning',
      'hi': 'बजट योजना',
    },
    '9tnc7ptc': {
      'en':
          'Create a detailed budget plan for an upcoming project, considering all relevant expenses, such as labor costs, materials, and external services. Collaborate with the finance team to ensure accuracy and alignment with overall financial...',
      'hi':
          'श्रम लागत, सामग्री और बाहरी सेवाओं जैसे सभी प्रासंगिक खर्चों पर विचार करते हुए, आगामी परियोजना के लिए एक विस्तृत बजट योजना बनाएं। समग्र वित्तीय के साथ सटीकता और संरेखण सुनिश्चित करने के लिए वित्त टीम के साथ सहयोग करें...',
    },
    'tffrersq': {
      'en': 'Active',
      'hi': 'सक्रिय',
    },
    '2am9qb9e': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    '0om288gt': {
      'en': '429242424',
      'hi': '429242424',
    },
    'c3a0kkoq': {
      'en': 'Client Onboarding Process',
      'hi': 'क्लाइंट ऑनबोर्डिंग प्रक्रिया',
    },
    'jmlgzphq': {
      'en':
          'Develop an efficient client onboarding process that streamlines the introduction of new clients to the company\'s services. Define clear steps, create necessary templates, and assign responsible team members for each task. Monitor the completion...',
      'hi':
          'एक कुशल क्लाइंट ऑनबोर्डिंग प्रक्रिया विकसित करें जो कंपनी की सेवाओं में नए ग्राहकों के परिचय को सुव्यवस्थित करे। स्पष्ट चरणों को परिभाषित करें, आवश्यक टेम्पलेट बनाएं और प्रत्येक कार्य के लिए जिम्मेदार टीम के सदस्यों को नियुक्त करें। पूर्णता की निगरानी करें...',
    },
    'fogg17ww': {
      'en': 'Active',
      'hi': 'सक्रिय',
    },
    'ijvvligx': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    '2j9l48s7': {
      'en': 'ID#: ',
      'hi': 'पहचान#:',
    },
    'hin6lqch': {
      'en': '429242424',
      'hi': '429242424',
    },
    '45cny0kv': {
      'en': 'Task 2',
      'hi': 'कार्य 2',
    },
    'f5nl0yj8': {
      'en':
          'Organize a training workshop for the team to enhance their skills and knowledge on a specific topic. Develop an agenda, source teaching materials, and coordinate logistics. Assign trainers and monitor attendance to ensure a successful...',
      'hi':
          'किसी विशिष्ट विषय पर टीम के कौशल और ज्ञान को बढ़ाने के लिए एक प्रशिक्षण कार्यशाला का आयोजन करें। एक एजेंडा विकसित करें, शिक्षण सामग्री प्राप्त करें और लॉजिस्टिक्स का समन्वय करें। सफल आयोजन सुनिश्चित करने के लिए प्रशिक्षक नियुक्त करें और उपस्थिति की निगरानी करें...',
    },
    'ejf4bhe5': {
      'en': 'Completed',
      'hi': 'पुरा होना।',
    },
    'bqkf7k8r': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // viewReportImageForRole
  {
    'unks3szr': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // surveyIntro
  {
    'cken2jvm': {
      'en': 'Harit\nParishar',
      'hi': 'हरित\nपरिषर',
    },
    'aevo07ux': {
      'en': 'Welcome to Our Green Revolution!',
      'hi': 'हमारी हरित क्रांति में आपका स्वागत है!',
    },
    'k1si9zhu': {
      'en':
          'Let\'s get started with a quick survey. Your responses will provide an initial estimate of your environmental footprint. \n\nRemember, there are no wrong answers here. This journey isn\'t about perfection; it\'s about making informed choices for positive change.',
      'hi':
          'आइए एक त्वरित सर्वेक्षण शुरू करें। आपकी प्रतिक्रियाएँ आपके पर्यावरणीय पदचिह्न का प्रारंभिक अनुमान प्रदान करेंगी।\n\nयाद रखें, यहां कोई गलत उत्तर नहीं हैं। यह यात्रा पूर्णता के बारे में नहीं है; यह सकारात्मक बदलाव के लिए सूचित विकल्प बनाने के बारे में है।',
    },
    'yq64vwyi': {
      'en': 'Let\'s Go!',
      'hi': 'चल दर!',
    },
    'e4aidrj6': {
      'en': 'No SignUp',
      'hi': 'कोई साइनअप नहीं',
    },
  },
  // Survey_Page
  {
    'opbml9qn': {
      'en': 'We need to Explore!',
      'hi': 'हमें अन्वेषण करने की आवश्यकता है!',
    },
    'g3dpj2f1': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // survey_result
  {
    'df6ves05': {
      'en': 'In Which Team are You Interested in ?',
      'hi': 'आप किस टीम में रुचि रखते हैं?',
    },
    '2xpd83tl': {
      'en': 'Afforestation for Green Spaces(AGS)',
      'hi': 'हरित स्थानों के लिए वनरोपण (एजीएस)',
    },
    '08ymfkoe': {
      'en': 'Circular Economy Practices(CEP)',
      'hi': 'सर्कुलर इकोनॉमी प्रैक्टिस (सीईपी)',
    },
    '4kdwcagq': {
      'en': 'Effective Water Management(EWM)',
      'hi': 'प्रभावी जल प्रबंधन (ईडब्ल्यूएम)',
    },
    'q19qbk31': {
      'en': 'Energy Efficiency Practices(EEP)',
      'hi': 'ऊर्जा दक्षता प्रथाएँ (ईईपी)',
    },
    'vdtldzw2': {
      'en': 'Food Waste Control Measures(FCM)',
      'hi': 'खाद्य अपशिष्ट नियंत्रण उपाय (एफसीएम)',
    },
    'ee4l3h5q': {
      'en': 'Green Infrastructure Development(GID)',
      'hi': 'हरित अवसंरचना विकास (जीआईडी)',
    },
    'zws9rjdb': {
      'en': 'Monitoring Carbon footprint(MCF)',
      'hi': 'कार्बन पदचिह्न की निगरानी (एमसीएफ)',
    },
    '559y4xch': {
      'en': 'Promoting Sustainable Research and Culture(PSRC)',
      'hi': 'सतत अनुसंधान और संस्कृति को बढ़ावा देना (पीएसआरसी)',
    },
    '6ziexvrl': {
      'en': 'Renewable Energy Sources(RES)',
      'hi': 'नवीकरणीय ऊर्जा स्रोत (आरईएस)',
    },
    'wll3mh3c': {
      'en': 'Sustainable Transportation Planning(STP)',
      'hi': 'सतत परिवहन योजना (एसटीपी)',
    },
    'rbzkw64v': {
      'en': 'Waste Reduction Strategies(WRS)',
      'hi': 'अपशिष्ट न्यूनीकरण रणनीतियाँ (डब्ल्यूआरएस)',
    },
    'sdwbo3o6': {
      'en': 'Please select...',
      'hi': 'कृपया चयन कीजिए...',
    },
    '8fiwqjc2': {
      'en': 'Search for an item...',
      'hi': 'कोई आइटम खोजें...',
    },
    '1qthqzbm': {
      'en': 'Next',
      'hi': 'अगला',
    },
    'st3uqych': {
      'en': 'Relative Score',
      'hi': 'सापेक्ष स्कोर',
    },
    'rt9h2im1': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // democalc
  {
    'u763440u': {
      'en': 'Back',
      'hi': '',
    },
    'g66p7b6b': {
      'en': 'Page Title',
      'hi': '',
    },
    'pvg5zbtk': {
      'en': 'Update Data',
      'hi': 'कार्य बनाएँ',
    },
    '49cyhiz7': {
      'en': 'How many gas cylinders do you use in a month ?',
      'hi': '',
    },
    'nl9v63so': {
      'en': 'No. of Gas Cylinders',
      'hi': 'कार्य का शीर्षक.......',
    },
    '96uwwfjj': {
      'en': 'What is your Monthly Electricity Units ?',
      'hi': '',
    },
    'u9r87501': {
      'en': 'No. of Electricity Units',
      'hi': 'कार्य का शीर्षक.......',
    },
    '5bowebrm': {
      'en': 'How much has your car travelled in the past year?',
      'hi': '',
    },
    '1aplfwve': {
      'en': 'No. of KM',
      'hi': 'कार्य का शीर्षक.......',
    },
    '9p5vodw2': {
      'en': 'How much has your bike travelled in the past year?',
      'hi': '',
    },
    'o316ocdm': {
      'en': 'No. of KM',
      'hi': 'कार्य का शीर्षक.......',
    },
    't69px419': {
      'en': 'Mileage of your Bike( Km/ Litre)',
      'hi': '',
    },
    '9s43di0z': {
      'en': 'Mileage Of Bike',
      'hi': 'कार्य का शीर्षक.......',
    },
    'wrf9m2j4': {
      'en': 'Mileage of your Car( Km/ Litre)',
      'hi': '',
    },
    '5rmuqd0y': {
      'en': 'Mileage Of Car',
      'hi': 'कार्य का शीर्षक.......',
    },
    '2r5i6gbj': {
      'en': 'Type of Your Car',
      'hi': '',
    },
    '3w57jjrk': {
      'en': 'Petrol',
      'hi': '',
    },
    'x1q9kicv': {
      'en': 'Diesel',
      'hi': '',
    },
    'mhrtvms5': {
      'en': 'No. of Water Litres Consumed',
      'hi': '',
    },
    '7me7lxsv': {
      'en': 'Water',
      'hi': 'कार्य का शीर्षक.......',
    },
    '9bsva12c': {
      'en': 'Upload Photo of Electricity Bill',
      'hi': 'कार्य से संबंधित फोटो अपलोड करें',
    },
    '81xprbo2': {
      'en': 'Upload Photo of Water Bill',
      'hi': 'कार्य से संबंधित फोटो अपलोड करें',
    },
    'kiyf9rqj': {
      'en': 'Update',
      'hi': '',
    },
    '7z6utsqy': {
      'en': 'Home',
      'hi': '',
    },
  },
  // Miscellaneous
  {
    'pwe7quln': {
      'en': '',
      'hi': '',
    },
    'jqhc5l7o': {
      'en': '',
      'hi': '',
    },
    '6ice81oi': {
      'en': '',
      'hi': '',
    },
    'hy1st5s1': {
      'en': '',
      'hi': '',
    },
    'p9lbizds': {
      'en': '',
      'hi': '',
    },
    'rp9yj62x': {
      'en': 'Please Allow Notifications',
      'hi': 'कृपया सूचनाओं की अनुमति दें',
    },
    'pscfzxdm': {
      'en': '',
      'hi': '',
    },
    'jto1750n': {
      'en': '',
      'hi': '',
    },
    'bj7tgmsl': {
      'en': '',
      'hi': '',
    },
    '1adwd8gt': {
      'en': '',
      'hi': '',
    },
    'q4rp860l': {
      'en': '',
      'hi': '',
    },
    'y94iuxa3': {
      'en': '',
      'hi': '',
    },
    'jynhlr5c': {
      'en': '',
      'hi': '',
    },
    'xc3z1fyu': {
      'en': '',
      'hi': '',
    },
    'c5p1jiif': {
      'en': '',
      'hi': '',
    },
    'qlwa8ww7': {
      'en': '',
      'hi': '',
    },
    '2lpy0z8c': {
      'en': '',
      'hi': '',
    },
    '76075dfp': {
      'en': '',
      'hi': '',
    },
    '1xt52b1x': {
      'en': '',
      'hi': '',
    },
    'cwj6vkav': {
      'en': '',
      'hi': '',
    },
    'fwjne7fm': {
      'en': '',
      'hi': '',
    },
    '3mmfvzv3': {
      'en': '',
      'hi': '',
    },
    'loz2q54e': {
      'en': '',
      'hi': '',
    },
    '9nap8ybn': {
      'en': '',
      'hi': '',
    },
    'c8ucxpaj': {
      'en': '',
      'hi': '',
    },
    'vmaddrzc': {
      'en': '',
      'hi': '',
    },
    'tund9q70': {
      'en': '',
      'hi': '',
    },
    'vokwdj86': {
      'en': '',
      'hi': '',
    },
    'u62wzg39': {
      'en': '',
      'hi': '',
    },
    '2v72kaxj': {
      'en': '',
      'hi': '',
    },
  },
].reduce((a, b) => a..addAll(b));
