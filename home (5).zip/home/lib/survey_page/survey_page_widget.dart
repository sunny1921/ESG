import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:provider/provider.dart';
import 'survey_page_model.dart';
export 'survey_page_model.dart';

class SurveyPageWidget extends StatefulWidget {
  const SurveyPageWidget({
    Key? key,
    this.question,
  }) : super(key: key);

  final DocumentReference? question;

  @override
  _SurveyPageWidgetState createState() => _SurveyPageWidgetState();
}

class _SurveyPageWidgetState extends State<SurveyPageWidget>
    with TickerProviderStateMixin {
  late SurveyPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = {
    'textOnPageLoadAnimation': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        FadeEffect(
          curve: Curves.easeInOut,
          delay: 0.ms,
          duration: 600.ms,
          begin: 0.0,
          end: 1.0,
        ),
        MoveEffect(
          curve: Curves.easeInOut,
          delay: 0.ms,
          duration: 600.ms,
          begin: Offset(0.0, 50.0),
          end: Offset(0.0, 0.0),
        ),
      ],
    ),
  };

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SurveyPageModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      // Reload_Screen
      _model.questionListf = await queryQuestionStudentRecordOnce();
    });

    setupAnimations(
      animationsMap.values.where((anim) =>
          anim.trigger == AnimationTrigger.onActionTrigger ||
          !anim.applyInitialState),
      this,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isiOS) {
      SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(
          statusBarBrightness: Theme.of(context).brightness,
          systemStatusBarContrastEnforced: true,
        ),
      );
    }

    context.watch<FFAppState>();

    return StreamBuilder<List<QuestionStudentRecord>>(
      stream: queryQuestionStudentRecord(),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: Color(0xFFE8F5E9),
            body: Center(
              child: SizedBox(
                width: 35.0,
                height: 35.0,
                child: SpinKitSquareCircle(
                  color: FlutterFlowTheme.of(context).lineColor,
                  size: 35.0,
                ),
              ),
            ),
          );
        }
        List<QuestionStudentRecord> surveyPageQuestionStudentRecordList =
            snapshot.data!;
        return GestureDetector(
          onTap: () => _model.unfocusNode.canRequestFocus
              ? FocusScope.of(context).requestFocus(_model.unfocusNode)
              : FocusScope.of(context).unfocus(),
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: Color(0xFFE8F5E9),
            appBar: responsiveVisibility(
              context: context,
              desktop: false,
            )
                ? AppBar(
                    backgroundColor: Color(0xFF2E5339),
                    automaticallyImplyLeading: false,
                    title: Text(
                      FFLocalizations.of(context).getText(
                        'opbml9qn' /* We need to Explore! */,
                      ),
                      style: FlutterFlowTheme.of(context).displaySmall.override(
                            fontFamily:
                                FlutterFlowTheme.of(context).displaySmallFamily,
                            color: Color(0xFFF5F5DC),
                            fontSize: 30.0,
                            useGoogleFonts: GoogleFonts.asMap().containsKey(
                                FlutterFlowTheme.of(context)
                                    .displaySmallFamily),
                          ),
                    ),
                    actions: [
                      Align(
                        alignment: AlignmentDirectional(0.0, 0.0),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 5.0, 16.0, 0.0),
                          child: FlutterFlowIconButton(
                            borderColor: Colors.transparent,
                            borderRadius: 50.0,
                            buttonSize: 30.0,
                            fillColor: Color(0xFFE8F5E9),
                            hoverColor: Color(0xFF87CEEB),
                            icon: Icon(
                              Icons.info,
                              color: Color(0xFF3A3A3A),
                              size: 15.0,
                            ),
                            onPressed: () {
                              print('IconButton pressed ...');
                            },
                          ),
                        ),
                      ),
                    ],
                    centerTitle: false,
                    elevation: 0.0,
                  )
                : null,
            body: SafeArea(
              top: true,
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Align(
                            alignment: AlignmentDirectional(-1.0, 0.0),
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  16.0, 12.0, 0.0, 0.0),
                              child: Text(
                                'Question ${(FFAppState().QuestionNumber + 1).toString()}/${surveyPageQuestionStudentRecordList.length.toString()}',
                                style: FlutterFlowTheme.of(context).labelMedium,
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                8.0, 12.0, 8.0, 0.0),
                            child: LinearPercentIndicator(
                              percent: FFAppState().QuestionNumber / 20,
                              width: MediaQuery.sizeOf(context).width * 0.95,
                              lineHeight: 12.0,
                              animation: true,
                              animateFromLastPercent: true,
                              progressColor: Color(0xFF3A3A3A),
                              backgroundColor: Color(0xFF87CEEB),
                              barRadius: Radius.circular(24.0),
                              padding: EdgeInsets.zero,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 5.0, 0.0, 0.0),
                            child: Text(
                              surveyPageQuestionStudentRecordList[
                                      FFAppState().QuestionNumber]
                                  .question,
                              textAlign: TextAlign.center,
                              style: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .override(
                                    fontFamily: FlutterFlowTheme.of(context)
                                        .titleSmallFamily,
                                    color: Colors.black,
                                    useGoogleFonts: GoogleFonts.asMap()
                                        .containsKey(
                                            FlutterFlowTheme.of(context)
                                                .titleSmallFamily),
                                  ),
                            ).animateOnPageLoad(
                                animationsMap['textOnPageLoadAnimation']!),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 15.0, 0.0, 0.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 10.0, 0.0, 0.0),
                                  child: FFButtonWidget(
                                    onPressed: () async {
                                      if (FFAppState().QuestionNumber >=
                                              (surveyPageQuestionStudentRecordList
                                                      .length -
                                                  1)
                                          ? true
                                          : false) {
                                        FFAppState().QuestionNumber =
                                            FFAppState().QuestionNumber +
                                                -FFAppState().QuestionNumber;
                                        FFAppState().Points =
                                            FFAppState().Points + 5;
                                        FFAppState().addToSelectedOptions(1);

                                        context.goNamed('survey_result');
                                      } else {
                                        setState(() {
                                          FFAppState().QuestionNumber =
                                              FFAppState().QuestionNumber + 1;
                                          FFAppState().Points =
                                              FFAppState().Points + 5;
                                          FFAppState().addToSelectedOptions(1);
                                        });
                                      }
                                    },
                                    text: surveyPageQuestionStudentRecordList[
                                            FFAppState().QuestionNumber]
                                        .option1,
                                    options: FFButtonOptions(
                                      height: 40.0,
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          24.0, 0.0, 24.0, 0.0),
                                      iconPadding:
                                          EdgeInsetsDirectional.fromSTEB(
                                              0.0, 0.0, 0.0, 0.0),
                                      color: Color(0xFF2E5339),
                                      textStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Hind Siliguri',
                                            color: Colors.white,
                                            useGoogleFonts: GoogleFonts.asMap()
                                                .containsKey(
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmallFamily),
                                          ),
                                      elevation: 3.0,
                                      borderSide: BorderSide(
                                        color: Color(0xFF87CEEB),
                                        width: 1.0,
                                      ),
                                      borderRadius: BorderRadius.circular(8.0),
                                      hoverColor: Color(0xFF6B8E23),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 10.0, 0.0, 0.0),
                                  child: FFButtonWidget(
                                    onPressed: () async {
                                      if (FFAppState().QuestionNumber >=
                                              (surveyPageQuestionStudentRecordList
                                                      .length -
                                                  1)
                                          ? true
                                          : false) {
                                        FFAppState().QuestionNumber =
                                            FFAppState().QuestionNumber +
                                                -FFAppState().QuestionNumber;
                                        FFAppState().Points =
                                            FFAppState().Points + 4;
                                        FFAppState().addToSelectedOptions(2);

                                        context.goNamed('survey_result');
                                      } else {
                                        setState(() {
                                          FFAppState().QuestionNumber =
                                              FFAppState().QuestionNumber + 1;
                                          FFAppState().Points =
                                              FFAppState().Points + 4;
                                          FFAppState().addToSelectedOptions(2);
                                        });
                                      }
                                    },
                                    text: surveyPageQuestionStudentRecordList[
                                            FFAppState().QuestionNumber]
                                        .option2,
                                    options: FFButtonOptions(
                                      height: 40.0,
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          24.0, 0.0, 24.0, 0.0),
                                      iconPadding:
                                          EdgeInsetsDirectional.fromSTEB(
                                              0.0, 0.0, 0.0, 0.0),
                                      color: Color(0xFF2E5339),
                                      textStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Hind Siliguri',
                                            color: Colors.white,
                                            useGoogleFonts: GoogleFonts.asMap()
                                                .containsKey(
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmallFamily),
                                          ),
                                      elevation: 3.0,
                                      borderSide: BorderSide(
                                        color: Color(0xFF87CEEB),
                                        width: 1.0,
                                      ),
                                      borderRadius: BorderRadius.circular(8.0),
                                      hoverColor: Color(0xFF6B8E23),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 10.0, 0.0, 0.0),
                                  child: FFButtonWidget(
                                    onPressed: () async {
                                      if (FFAppState().QuestionNumber >=
                                              (surveyPageQuestionStudentRecordList
                                                      .length -
                                                  1)
                                          ? true
                                          : false) {
                                        FFAppState().QuestionNumber =
                                            FFAppState().QuestionNumber +
                                                -FFAppState().QuestionNumber;
                                        FFAppState().Points =
                                            FFAppState().Points + 3;
                                        FFAppState().addToSelectedOptions(3);

                                        context.goNamed('survey_result');
                                      } else {
                                        setState(() {
                                          FFAppState().QuestionNumber =
                                              FFAppState().QuestionNumber + 1;
                                          FFAppState().Points =
                                              FFAppState().Points + 3;
                                          FFAppState().addToSelectedOptions(3);
                                        });
                                      }
                                    },
                                    text: surveyPageQuestionStudentRecordList[
                                            FFAppState().QuestionNumber]
                                        .option3,
                                    options: FFButtonOptions(
                                      height: 40.0,
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          24.0, 0.0, 24.0, 0.0),
                                      iconPadding:
                                          EdgeInsetsDirectional.fromSTEB(
                                              0.0, 0.0, 0.0, 0.0),
                                      color: Color(0xFF2E5339),
                                      textStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Hind Siliguri',
                                            color: Colors.white,
                                            useGoogleFonts: GoogleFonts.asMap()
                                                .containsKey(
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmallFamily),
                                          ),
                                      elevation: 3.0,
                                      borderSide: BorderSide(
                                        color: Color(0xFF87CEEB),
                                        width: 1.0,
                                      ),
                                      borderRadius: BorderRadius.circular(8.0),
                                      hoverColor: Color(0xFF6B8E23),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 10.0, 0.0, 0.0),
                                  child: FFButtonWidget(
                                    onPressed: () async {
                                      if (FFAppState().QuestionNumber >=
                                              (surveyPageQuestionStudentRecordList
                                                      .length -
                                                  1)
                                          ? true
                                          : false) {
                                        FFAppState().QuestionNumber =
                                            FFAppState().QuestionNumber +
                                                -FFAppState().QuestionNumber;
                                        FFAppState().Points =
                                            FFAppState().Points + 2;
                                        FFAppState().addToSelectedOptions(4);

                                        context.goNamed('survey_result');
                                      } else {
                                        setState(() {
                                          FFAppState().QuestionNumber =
                                              FFAppState().QuestionNumber + 1;
                                          FFAppState().Points =
                                              FFAppState().Points + 2;
                                          FFAppState().addToSelectedOptions(4);
                                        });
                                      }
                                    },
                                    text: surveyPageQuestionStudentRecordList[
                                            FFAppState().QuestionNumber]
                                        .option4,
                                    options: FFButtonOptions(
                                      height: 40.0,
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          24.0, 0.0, 24.0, 0.0),
                                      iconPadding:
                                          EdgeInsetsDirectional.fromSTEB(
                                              0.0, 0.0, 0.0, 0.0),
                                      color: Color(0xFF2E5339),
                                      textStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Hind Siliguri',
                                            color: Colors.white,
                                            useGoogleFonts: GoogleFonts.asMap()
                                                .containsKey(
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmallFamily),
                                          ),
                                      elevation: 3.0,
                                      borderSide: BorderSide(
                                        width: 1.0,
                                      ),
                                      borderRadius: BorderRadius.circular(8.0),
                                      hoverColor: Color(0xFF6B8E23),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 10.0, 0.0, 0.0),
                                  child: FFButtonWidget(
                                    onPressed: () async {
                                      if (FFAppState().QuestionNumber >=
                                              (surveyPageQuestionStudentRecordList
                                                      .length -
                                                  1)
                                          ? true
                                          : false) {
                                        FFAppState().QuestionNumber =
                                            FFAppState().QuestionNumber +
                                                -FFAppState().QuestionNumber;
                                        FFAppState().Points =
                                            FFAppState().Points + 1;
                                        FFAppState().addToSelectedOptions(5);

                                        context.goNamed('survey_result');
                                      } else {
                                        setState(() {
                                          FFAppState().QuestionNumber =
                                              FFAppState().QuestionNumber + 1;
                                          FFAppState().Points =
                                              FFAppState().Points + 1;
                                          FFAppState().addToSelectedOptions(5);
                                        });
                                      }
                                    },
                                    text: surveyPageQuestionStudentRecordList[
                                            FFAppState().QuestionNumber]
                                        .option5,
                                    options: FFButtonOptions(
                                      height: 40.0,
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          24.0, 0.0, 24.0, 0.0),
                                      iconPadding:
                                          EdgeInsetsDirectional.fromSTEB(
                                              0.0, 0.0, 0.0, 0.0),
                                      color: Color(0xFF2E5339),
                                      textStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Hind Siliguri',
                                            color: Colors.white,
                                            useGoogleFonts: GoogleFonts.asMap()
                                                .containsKey(
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmallFamily),
                                          ),
                                      elevation: 3.0,
                                      borderSide: BorderSide(
                                        width: 1.0,
                                      ),
                                      borderRadius: BorderRadius.circular(8.0),
                                      hoverColor: Color(0xFF6B8E23),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            0.0, 0.0, 150.0, 15.0),
                        child: FlutterFlowIconButton(
                          borderColor: Colors.transparent,
                          borderRadius: 20.0,
                          borderWidth: 1.0,
                          buttonSize: 40.0,
                          fillColor: Color(0xFF2E5339),
                          icon: Icon(
                            Icons.chevron_left,
                            color: Color(0xFF87CEEB),
                            size: 24.0,
                          ),
                          onPressed: () {
                            print('IconButton pressed ...');
                          },
                        ),
                      ),
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            100.0, 0.0, 0.0, 0.0),
                        child: FlutterFlowIconButton(
                          borderColor: Colors.transparent,
                          borderRadius: 20.0,
                          borderWidth: 1.0,
                          buttonSize: 40.0,
                          fillColor: Color(0xFF2E5339),
                          icon: Icon(
                            Icons.navigate_next,
                            color: Color(0xFF87CEEB),
                            size: 24.0,
                          ),
                          onPressed: () {
                            print('IconButton pressed ...');
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
