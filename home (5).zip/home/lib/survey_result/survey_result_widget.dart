import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'package:auto_size_text/auto_size_text.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'survey_result_model.dart';
export 'survey_result_model.dart';

class SurveyResultWidget extends StatefulWidget {
  const SurveyResultWidget({Key? key}) : super(key: key);

  @override
  _SurveyResultWidgetState createState() => _SurveyResultWidgetState();
}

class _SurveyResultWidgetState extends State<SurveyResultWidget> {
  late SurveyResultModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SurveyResultModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isiOS) {
      SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(
          statusBarBrightness: Theme.of(context).brightness,
          systemStatusBarContrastEnforced: true,
        ),
      );
    }

    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: responsiveVisibility(
          context: context,
          desktop: false,
        )
            ? AppBar(
                backgroundColor: FlutterFlowTheme.of(context).primary,
                automaticallyImplyLeading: false,
                title: Padding(
                  padding: EdgeInsets.all(2.0),
                  child: Text(
                    FFLocalizations.of(context).getText(
                      'st3uqych' /* Relative Score */,
                    ),
                    textAlign: TextAlign.center,
                    style: FlutterFlowTheme.of(context).displaySmall,
                  ),
                ),
                actions: [],
                centerTitle: false,
                elevation: 2.0,
              )
            : null,
        body: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Divider(
                    thickness: 1.0,
                    color: FlutterFlowTheme.of(context).accent4,
                  ),
                  Container(
                    width: MediaQuery.sizeOf(context).width * 0.9,
                    height: 500.0,
                    child: custom_widgets.TripleCircularProgress(
                      width: 350.0,
                      height: 500.0,
                      progress1: FFAppState().Points.toDouble(),
                      progress2: 83.0,
                      progress3: 84.0,
                      numquest: 20.0,
                    ),
                  ),
                ],
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: EdgeInsets.all(24.0),
                      child: AutoSizeText(
                        FFLocalizations.of(context).getText(
                          'df6ves05' /* In Which Team are You Interest... */,
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily:
                                  FlutterFlowTheme.of(context).bodyMediumFamily,
                              fontSize: 20.0,
                              useGoogleFonts: GoogleFonts.asMap().containsKey(
                                  FlutterFlowTheme.of(context)
                                      .bodyMediumFamily),
                            ),
                        minFontSize: 20.0,
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 25.0, 0.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          FlutterFlowDropDown<String>(
                            controller:
                                _model.dropDownForTeamValueController ??=
                                    FormFieldController<String>(null),
                            options: [
                              FFLocalizations.of(context).getText(
                                '2xpd83tl' /* Afforestation for Green Spaces... */,
                              ),
                              FFLocalizations.of(context).getText(
                                '08ymfkoe' /* Circular Economy Practices(CEP... */,
                              ),
                              FFLocalizations.of(context).getText(
                                '4kdwcagq' /* Effective Water Management(EWM... */,
                              ),
                              FFLocalizations.of(context).getText(
                                'q19qbk31' /* Energy Efficiency Practices(EE... */,
                              ),
                              FFLocalizations.of(context).getText(
                                'vdtldzw2' /* Food Waste Control Measures(FC... */,
                              ),
                              FFLocalizations.of(context).getText(
                                'ee4l3h5q' /* Green Infrastructure Developme... */,
                              ),
                              FFLocalizations.of(context).getText(
                                'zws9rjdb' /* Monitoring Carbon footprint(MC... */,
                              ),
                              FFLocalizations.of(context).getText(
                                '559y4xch' /* Promoting Sustainable Research... */,
                              ),
                              FFLocalizations.of(context).getText(
                                '6ziexvrl' /* Renewable Energy Sources(RES) */,
                              ),
                              FFLocalizations.of(context).getText(
                                'wll3mh3c' /* Sustainable Transportation Pla... */,
                              ),
                              FFLocalizations.of(context).getText(
                                'rbzkw64v' /* Waste Reduction Strategies(WRS... */,
                              )
                            ],
                            onChanged: (val) async {
                              setState(() => _model.dropDownForTeamValue = val);
                              await currentUserReference!
                                  .update(createUsersRecordData(
                                team: _model.dropDownForTeamValue,
                              ));
                            },
                            width: 250.0,
                            height: 50.0,
                            searchHintTextStyle:
                                FlutterFlowTheme.of(context).labelMedium,
                            textStyle: FlutterFlowTheme.of(context).bodyMedium,
                            hintText: FFLocalizations.of(context).getText(
                              'sdwbo3o6' /* Please select... */,
                            ),
                            searchHintText: FFLocalizations.of(context).getText(
                              '8fiwqjc2' /* Search for an item... */,
                            ),
                            icon: Icon(
                              Icons.keyboard_arrow_down_rounded,
                              color: FlutterFlowTheme.of(context).secondaryText,
                              size: 24.0,
                            ),
                            fillColor: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                            elevation: 2.0,
                            borderColor: FlutterFlowTheme.of(context).alternate,
                            borderWidth: 2.0,
                            borderRadius: 8.0,
                            margin: EdgeInsetsDirectional.fromSTEB(
                                16.0, 4.0, 16.0, 4.0),
                            hidesUnderline: true,
                            isOverButton: true,
                            isSearchable: true,
                            isMultiSelect: false,
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 25.0, 0.0, 15.0),
                            child: FFButtonWidget(
                              onPressed: () async {
                                await currentUserReference!.update({
                                  ...createUsersRecordData(
                                    surveyScore: FFAppState().Points.toDouble(),
                                  ),
                                  ...mapToFirestore(
                                    {
                                      'surveySelectedOptions':
                                          FFAppState().SelectedOptions,
                                    },
                                  ),
                                });

                                context.goNamed('HomePage');
                              },
                              text: FFLocalizations.of(context).getText(
                                '1qthqzbm' /* Next */,
                              ),
                              options: FFButtonOptions(
                                height: 40.0,
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    24.0, 0.0, 24.0, 0.0),
                                iconPadding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 0.0, 0.0),
                                color: FlutterFlowTheme.of(context).secondary,
                                textStyle: FlutterFlowTheme.of(context)
                                    .titleSmall
                                    .override(
                                      fontFamily: FlutterFlowTheme.of(context)
                                          .titleSmallFamily,
                                      color: Colors.white,
                                      useGoogleFonts: GoogleFonts.asMap()
                                          .containsKey(
                                              FlutterFlowTheme.of(context)
                                                  .titleSmallFamily),
                                    ),
                                elevation: 3.0,
                                borderSide: BorderSide(
                                  color: Colors.transparent,
                                  width: 1.0,
                                ),
                                borderRadius: BorderRadius.circular(50.0),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
